# DASTAWAIZ Google Sheets CRM — Complete Setup Guide

## SHEET NAME: DASTAWAIZ CRM

## TAB 1: LEADS (main tracking sheet)

### EXACT COLUMN HEADERS (Row 1):
A: Matter ID
B: Date Received
C: Client Name
D: WhatsApp Number
E: Email Address
F: Service Type
G: Document Type
H: Jurisdiction
I: Urgency
J: Lead Source
K: Status
L: Notes / Special Requirements
M: Quote Amount (PKR)
N: Quote Sent Date
O: Payment Status
P: Payment Reference
Q: Payment Date
R: Drive Folder Link
S: AI Draft Done
T: Human Review Done
U: QC Done
V: Delivery Date
W: Follow-Up Done
X: Cross-Sell Opportunity
Y: Referred To
Z: Repeat Client

---

## TAB 2: STATUS REFERENCE (dropdown values)

### Column K — Status Options:
- New Lead
- Under Review
- Info Needed
- Quote Sent
- Awaiting Payment
- Paid
- In Progress
- Human Review
- QC
- Ready to Deliver
- Delivered
- Completed
- Follow-Up Done
- Closed
- Referred — BTaxFiler
- Referred — Mr. Laws
- Declined

### Column F — Service Type Options:
- Contract Creation
- Contract Review
- Legal Question
- Startup Package
- IT Business Package
- Custom

### Column G — Document Type Options:
- NDA / Confidentiality Agreement
- Freelancer Agreement
- Employment Agreement
- Consultancy Agreement
- Software Development Agreement
- Partnership Agreement
- Lease / Rent Agreement
- Shareholders Agreement
- Vendor Agreement
- Service Agreement
- Terms & Conditions
- Privacy Policy
- MOU
- Loan Agreement
- Settlement Agreement
- Commission Agreement
- Agency Agreement
- IP Agreement
- E-commerce Agreement
- Other / Custom

### Column I — Urgency Options:
- Standard (5–7 days)
- Urgent (2–3 days)
- Same Day

### Column J — Lead Source Options:
- Google Search
- Instagram
- LinkedIn
- Facebook
- TikTok
- YouTube
- WhatsApp
- BTaxFiler Referral
- Mr. Laws Referral
- Client Referral
- Blog Article
- Direct / Unknown

### Column O — Payment Status Options:
- Not Invoiced
- Quote Sent
- Awaiting Payment
- Payment Received
- Verified

---

## TAB 3: MATTER ID TRACKER

### Used to auto-increment Matter IDs
Column A: Last Matter Number
Column B: Current Year
Column C: Next ID to Use

### Manual Rule:
- First matter: DA-2026-0001
- Second matter: DA-2026-0002
- New year resets: DA-2027-0001

---

## TAB 4: EMAIL TEMPLATES (quick copy-paste)

### Template 1 — Acknowledgment
Subject: Your DASTAWAIZ Request — [Matter ID]

Dear [Client Name],

Thank you for contacting DASTAWAIZ.

Your request has been received and assigned reference number [Matter ID].

We will review your submission and respond within 24 hours with any questions or a quotation.

If you have any immediate queries, you can reach us on WhatsApp: [Your Number]

Warm regards,
DASTAWAIZ Team

---

### Template 2 — Info Required
Subject: Additional Information Required — [Matter ID]

Dear [Client Name],

Thank you for your submission (Ref: [Matter ID]).

To proceed with your request, we require the following additional information:

[List what you need]

Please reply to this email or send the information via WhatsApp at your earliest convenience.

Warm regards,
DASTAWAIZ Team

---

### Template 3 — Quotation
Subject: Quotation for Legal Document Services — [Matter ID]

Dear [Client Name],

Thank you for your patience. Following review of your request (Ref: [Matter ID]), we are pleased to provide the following quotation:

Service: [Document Type]
Fee: PKR [Amount]
Turnaround: [X] working days from payment confirmation
Includes: [Draft + 1 revision / Review + written comments / etc.]

Payment Methods:
- Bank Transfer: [Your bank details]
- Easypaisa: [Number]
- JazzCash: [Number]
- Raast ID: [ID]

Please send payment confirmation (screenshot or transaction reference) via WhatsApp or reply to this email.

This quotation is valid for 7 days.

Warm regards,
DASTAWAIZ Team

---

### Template 4 — Payment Confirmed
Subject: Payment Confirmed — Work Commencing — [Matter ID]

Dear [Client Name],

Thank you. We have received and verified your payment for Matter [Matter ID].

Work has now commenced on your [Document Type].

Expected delivery: [Date]

We will contact you if any clarification is required during preparation.

Warm regards,
DASTAWAIZ Team

---

### Template 5 — Document Delivery
Subject: Your Document is Ready — [Matter ID]

Dear [Client Name],

Your [Document Type] is now complete and ready for delivery.

Please find the document attached / accessible via the secure link below:

[Google Drive Link — set to "Anyone with link can view"]

Document Details:
- Document: [Name]
- Version: Final v1
- Date: [Date]
- Matter ID: [Matter ID]

Important: Please review the document carefully. One reasonable revision is included within 7 days of delivery. Major structural changes may require an additional fee.

This document has been prepared based on the information you provided. It is recommended that you read the document fully before signing or sharing with any other party.

Warm regards,
DASTAWAIZ Team

---

### Template 6 — Follow-Up
Subject: Following Up — [Matter ID]

Dear [Client Name],

We hope you found our service satisfactory.

We wanted to follow up to ensure the document met your requirements and to ask if you have any further legal document needs we can assist with.

If you have a moment, a Google review would be greatly appreciated:
[Google Business Profile Link]

We also assist with:
- Contract review and vetting
- Employment agreements
- Business legal documents
- [Relevant cross-sell]

Thank you for choosing DASTAWAIZ.

Warm regards,
DASTAWAIZ Team

---

## TAB 5: PRICING REFERENCE

| Document Type | Standard (PKR) | Urgent (+50%) | Notes |
|---|---|---|---|
| NDA | 2,500 | 3,750 | Fixed |
| Freelancer Agreement | 3,500 | 5,250 | Fixed |
| Employment Agreement | 4,000 | 6,000 | Fixed |
| Consultancy Agreement | 4,000 | 6,000 | Fixed |
| Software Dev Agreement | 7,500 | 11,250 | Fixed |
| Partnership Agreement | 10,000 | 15,000 | Fixed |
| Lease Agreement | 3,500 | 5,250 | Fixed |
| Shareholders Agreement | 12,000 | 18,000 | Quote |
| Contract Review (basic) | 4,000 | 6,000 | Per doc |
| Contract Review (complex) | 8,000+ | 12,000+ | Quote |
| Legal Question (written) | 2,500 | — | Per matter |
| Startup Package (3 docs) | 14,000 | — | Bundle |
| IT Business Package (5 docs) | 22,000 | — | Bundle |

/**
 * DASTAWAIZ — Google Apps Script
 * Paste this into Google Sheets → Extensions → Apps Script
 * Replace YOUR_EMAIL and YOUR_WHATSAPP_NUMBER before saving
 */

const ADMIN_EMAIL = "YOUR_GMAIL_HERE@gmail.com"; // <-- change this
const SHEET_NAME = "LEADS";
const MATTER_PREFIX = "DA-2026-";

/**
 * Called automatically when a Google Form is submitted.
 * Adds a new row to the LEADS sheet and sends admin email.
 */
function onFormSubmit(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const leadsSheet = ss.getSheetByName(SHEET_NAME);
  const trackerSheet = ss.getSheetByName("MATTER ID TRACKER");

  // --- Generate Matter ID ---
  let lastNum = trackerSheet.getRange("A2").getValue();
  let newNum = lastNum + 1;
  trackerSheet.getRange("A2").setValue(newNum);
  const matterId = MATTER_PREFIX + String(newNum).padStart(4, "0");

  // --- Get form response ---
  const responses = e.namedValues;

  const clientName    = (responses["Full Name"] || [""])[0];
  const whatsapp      = (responses["WhatsApp Number"] || [""])[0];
  const email         = (responses["Email Address"] || [""])[0];
  const serviceType   = (responses["Service Type"] || [""])[0];
  const documentType  = (responses["Document Type"] || [""])[0];
  const jurisdiction  = (responses["Jurisdiction / Country"] || [""])[0];
  const urgency       = (responses["Urgency"] || ["Standard (5–7 days)"])[0];
  const leadSource    = (responses["How did you find us?"] || [""])[0];
  const notes         = (responses["Additional Details / Requirements"] || [""])[0];

  const dateReceived  = new Date();

  // --- Append row to LEADS sheet ---
  leadsSheet.appendRow([
    matterId,           // A: Matter ID
    dateReceived,       // B: Date Received
    clientName,         // C: Client Name
    whatsapp,           // D: WhatsApp Number
    email,              // E: Email Address
    serviceType,        // F: Service Type
    documentType,       // G: Document Type
    jurisdiction,       // H: Jurisdiction
    urgency,            // I: Urgency
    leadSource,         // J: Lead Source
    "New Lead",         // K: Status
    notes,              // L: Notes
    "",                 // M: Quote Amount
    "",                 // N: Quote Sent Date
    "Not Invoiced",     // O: Payment Status
    "",                 // P: Payment Reference
    "",                 // Q: Payment Date
    "",                 // R: Drive Folder Link
    "No",               // S: AI Draft Done
    "No",               // T: Human Review Done
    "No",               // U: QC Done
    "",                 // V: Delivery Date
    "No",               // W: Follow-Up Done
    "",                 // X: Cross-Sell Opportunity
    "",                 // Y: Referred To
    "No"                // Z: Repeat Client
  ]);

  // --- Send admin notification email ---
  const subject = `🔔 New DASTAWAIZ Lead — ${matterId} — ${documentType}`;
  const body = `
New lead received on DASTAWAIZ.

━━━━━━━━━━━━━━━━━━━━
MATTER ID: ${matterId}
DATE: ${dateReceived.toLocaleString()}
━━━━━━━━━━━━━━━━━━━━

CLIENT DETAILS:
Name: ${clientName}
WhatsApp: ${whatsapp}
Email: ${email}

SERVICE REQUESTED:
Service: ${serviceType}
Document: ${documentType}
Jurisdiction: ${jurisdiction}
Urgency: ${urgency}
Lead Source: ${leadSource}

NOTES / REQUIREMENTS:
${notes}

━━━━━━━━━━━━━━━━━━━━
ACTION REQUIRED: Open Google Sheet and update status.
━━━━━━━━━━━━━━━━━━━━
  `;

  GmailApp.sendEmail(ADMIN_EMAIL, subject, body);

  // --- Send client acknowledgment ---
  if (email) {
    const clientSubject = `Your DASTAWAIZ Request — ${matterId}`;
    const clientBody = `
Dear ${clientName},

Thank you for contacting DASTAWAIZ.

Your request has been received and assigned reference number: ${matterId}

We will review your submission and respond within 24 hours with any questions or a quotation.

If you have any immediate queries, you can reach us on WhatsApp.

Please keep your reference number for all future correspondence.

Warm regards,
DASTAWAIZ Team
dastawaiz.com
    `;
    GmailApp.sendEmail(email, clientSubject, clientBody);
  }
}

/**
 * Creates the Google Drive client folder automatically.
 * Call this manually from the Apps Script editor when a new matter is created.
 * Or run it from a custom menu (see below).
 */
function createClientFolder() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);
  const ui = SpreadsheetApp.getUi();

  // Get active row
  const row = sheet.getActiveCell().getRow();
  if (row <= 1) {
    ui.alert("Please select a data row (not the header).");
    return;
  }

  const matterId   = sheet.getRange(row, 1).getValue();
  const clientName = sheet.getRange(row, 3).getValue();

  if (!matterId || !clientName) {
    ui.alert("Matter ID or Client Name is missing in this row.");
    return;
  }

  // Get or create year folder inside DASTAWAIZ Clients
  const rootFolderName = "DASTAWAIZ Clients";
  const year = new Date().getFullYear().toString();
  const folderName = `${matterId} — ${clientName}`;

  let rootFolder;
  const rootFolders = DriveApp.getFoldersByName(rootFolderName);
  if (rootFolders.hasNext()) {
    rootFolder = rootFolders.next();
  } else {
    rootFolder = DriveApp.createFolder(rootFolderName);
  }

  let yearFolder;
  const yearFolders = rootFolder.getFoldersByName(year);
  if (yearFolders.hasNext()) {
    yearFolder = yearFolders.next();
  } else {
    yearFolder = rootFolder.createFolder(year);
  }

  // Create client matter folder with subfolders
  const clientFolder = yearFolder.createFolder(folderName);
  clientFolder.createFolder("01 — Original Documents");
  clientFolder.createFolder("02 — Working Drafts");
  clientFolder.createFolder("03 — Final Documents");
  clientFolder.createFolder("04 — Communications");

  // Save folder link back to sheet
  const folderUrl = clientFolder.getUrl();
  sheet.getRange(row, 18).setValue(folderUrl); // Column R

  ui.alert(`Folder created successfully!\n\nFolder: ${folderName}\nLink saved in column R.`);
}

/**
 * Adds a custom menu to the Google Sheet for easy access.
 */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("DASTAWAIZ")
    .addItem("Create Client Folder", "createClientFolder")
    .addToUi();
}

# DASTAWAIZ — Google Forms Setup (All 3 Forms)

---

## FORM 1: CONTRACT CREATION REQUEST

**Form Title:** Create My Contract — DASTAWAIZ
**Description:** Tell us about the document you need. We will review your request and send you a quotation within 24 hours.

---

### SECTION 1: Your Details

Q1. Full Name *
Type: Short answer

Q2. WhatsApp Number *
Type: Short answer
Helper: Include country code e.g. +92 300 1234567

Q3. Email Address *
Type: Short answer

Q4. Are you an individual or a business? *
Type: Multiple choice
Options:
- Individual / Freelancer
- Registered Business / Company
- Startup
- Other

---

### SECTION 2: Document Details

Q5. What type of document do you need? *
Type: Dropdown
Options:
- NDA / Confidentiality Agreement
- Freelancer Agreement
- Employment Agreement
- Consultancy Agreement
- Software Development Agreement
- Partnership Agreement
- Lease / Rent Agreement
- Shareholders Agreement
- Vendor / Supplier Agreement
- Service Agreement
- Terms & Conditions
- Privacy Policy
- MOU (Memorandum of Understanding)
- Loan Agreement
- Commission Agreement
- Agency Agreement
- IP / Intellectual Property Agreement
- E-commerce Agreement
- Other / Custom (describe below)

Q6. Briefly describe the parties involved *
Type: Paragraph
Helper: e.g. "I am a freelance developer. My client is a UK-based company. I need to protect my work and ensure I get paid."

Q7. What is the main purpose of this document? *
Type: Paragraph
Helper: e.g. "To define payment terms, deliverables and IP ownership for a 3-month software project."

Q8. Jurisdiction / Country *
Type: Short answer
Helper: Which country's law should govern this document? e.g. Pakistan, UAE, UK

Q9. Any specific terms, clauses or requirements? 
Type: Paragraph
Helper: Optional — leave blank if unsure. We will ask if needed.

---

### SECTION 3: Timing & Source

Q10. How urgently do you need this? *
Type: Multiple choice
Options:
- Standard — 5 to 7 working days
- Urgent — 2 to 3 working days (additional fee applies)
- Same Day (subject to availability — additional fee applies)

Q11. How did you find DASTAWAIZ? *
Type: Dropdown
Options:
- Google Search
- Instagram
- LinkedIn
- Facebook
- TikTok
- YouTube
- WhatsApp
- BTaxFiler
- Mr. Laws
- Referred by someone
- Blog / Article
- Other

---

### CONFIRMATION MESSAGE (shown after submit):
"Thank you! Your request has been received.

Reference number will be assigned and sent to your email within a few minutes.

We will review your request and send a quotation within 24 hours.

For urgent matters, WhatsApp us directly."

---
---

## FORM 2: CONTRACT REVIEW / VETTING REQUEST

**Form Title:** Review My Contract — DASTAWAIZ
**Description:** Upload your agreement for professional review. We will identify risks, missing clauses and provide written recommendations.

---

### SECTION 1: Your Details

Q1. Full Name *
Type: Short answer

Q2. WhatsApp Number *
Type: Short answer

Q3. Email Address *
Type: Short answer

---

### SECTION 2: Document Details

Q4. What type of document are you uploading? *
Type: Dropdown
Options: [same as Form 1 document types]

Q5. What is your position in this agreement? *
Type: Multiple choice
Options:
- Party A
- Party B
- Employer
- Employee
- Client
- Service Provider
- Buyer
- Seller
- Landlord
- Tenant
- Consultant
- Other

Q6. What is your main concern or question about this document? *
Type: Paragraph
Helper: e.g. "I want to know if this agreement protects me if the client does not pay. Also, the termination clause seems one-sided."

Q7. Jurisdiction / Country *
Type: Short answer
Helper: Which country's law applies to this document?

Q8. Upload your document *
Type: File upload
Settings:
- Allow only: PDF, DOC, DOCX
- Maximum files: 1
- Maximum file size: 10 MB

Q9. I confirm I am authorized to share this document for review *
Type: Checkbox (required)
Options: Yes, I confirm

---

### SECTION 3: Timing & Source

Q10. How urgently do you need this review? *
Type: Multiple choice
Options:
- Standard — 5 to 7 working days
- Urgent — 2 to 3 working days (additional fee applies)
- Same Day (subject to availability)

Q11. How did you find DASTAWAIZ? *
Type: Dropdown
Options: [same as Form 1]

---

### SECTION 4: Consent

Q12. I understand that this review is provided by DASTAWAIZ as a professional document review service. The review comments do not constitute legal advice and do not create a lawyer-client relationship. I accept the DASTAWAIZ Terms of Use. *
Type: Checkbox (required)
Options: I agree

---

### CONFIRMATION MESSAGE:
"Thank you for uploading your document.

Your request has been received and will be reviewed shortly. A reference number will be assigned and sent to your email.

We will send you a quotation within 24 hours.

Your document is handled with strict confidentiality."

---
---

## FORM 3: ASK A LEGAL / CONTRACT QUESTION

**Form Title:** Ask a Legal Question — DASTAWAIZ
**Description:** Have a question about a contract or legal document? Describe your situation and we will provide a written response.

---

### SECTION 1: Your Details

Q1. Full Name *
Type: Short answer

Q2. WhatsApp Number *
Type: Short answer

Q3. Email Address *
Type: Short answer

---

### SECTION 2: Your Question

Q4. What is your question about? *
Type: Dropdown
Options:
- Is this clause enforceable?
- Is this agreement safe for me?
- What risks do I have?
- What clauses are missing?
- Can I terminate this agreement?
- What happens if the other party breaches?
- How can I protect my business?
- What should I negotiate?
- What legal remedies are available?
- Other / General contract question

Q5. Type of document involved *
Type: Dropdown
Options: [same document types]

Q6. Which country / jurisdiction does this involve? *
Type: Short answer

Q7. Describe your situation and question in detail *
Type: Paragraph
Helper: The more detail you provide, the more useful our response will be.

Q8. Upload document (optional)
Type: File upload
Settings:
- Allow only: PDF, DOC, DOCX
- Maximum files: 1
- Maximum file size: 10 MB

Q9. I confirm I am authorized to share any uploaded document *
Type: Checkbox
Options: Yes, I confirm

---

### SECTION 3: Source

Q10. How did you find DASTAWAIZ? *
Type: Dropdown
Options: [same as Form 1]

---

### CONFIRMATION MESSAGE:
"Thank you for your question.

Your reference number will be sent to your email shortly.

We will review your query and respond with a written answer within 24 hours.

Please note: Our written responses provide general guidance based on the information you have shared. For matters requiring full legal representation, we will advise you accordingly."

---

## HOW TO LINK FORMS TO GOOGLE SHEET

1. Open Google Form
2. Click "Responses" tab at top
3. Click the green Sheets icon
4. Select "Create a new spreadsheet" — name it "DASTAWAIZ CRM"
5. Repeat for Forms 2 and 3 — link to SAME spreadsheet, different tabs
6. Rename tabs: "Form1 — Create", "Form2 — Review", "Form3 — Question"
7. Create a 4th tab manually called "LEADS" — this is your master CRM
8. Use Apps Script to pull data from form tabs into LEADS

# DASTAWAIZ — Google Drive Folder Structure

## HOW TO CREATE THIS IN GOOGLE DRIVE:

Go to drive.google.com
Create each folder exactly as named below.

---

## MASTER STRUCTURE:

📁 DASTAWAIZ (root folder — share nothing from here)
│
├── 📁 DASTAWAIZ Clients
│   ├── 📁 2026
│   │   ├── 📁 DA-2026-0001 — [Client Name]
│   │   │   ├── 📁 01 — Original Documents
│   │   │   ├── 📁 02 — Working Drafts
│   │   │   ├── 📁 03 — Final Documents
│   │   │   └── 📁 04 — Communications
│   │   ├── 📁 DA-2026-0002 — [Client Name]
│   │   └── (new folder for each matter)
│   └── 📁 2027 (create when year changes)
│
├── 📁 DASTAWAIZ Internal
│   ├── 📁 Templates
│   │   ├── NDA Template — Base.docx
│   │   ├── Freelancer Agreement — Base.docx
│   │   ├── Employment Agreement — Base.docx
│   │   ├── Consultancy Agreement — Base.docx
│   │   ├── Software Dev Agreement — Base.docx
│   │   ├── Partnership Agreement — Base.docx
│   │   └── Lease Agreement — Base.docx
│   ├── 📁 Checklists
│   │   ├── QC Checklist.docx
│   │   └── Review Checklist.docx
│   ├── 📁 Email Templates
│   │   └── All Templates.docx
│   ├── 📁 Pricing
│   │   └── Current Pricing.docx
│   └── 📁 Claude Prompts
│       └── All Prompts.docx
│
└── 📁 DASTAWAIZ Website
    ├── 📁 Images
    ├── 📁 Logo Files
    └── 📁 Blog Drafts

---

## GOOGLE DRIVE ACCESS RULES:

- NEVER make client folders public
- When delivering documents:
  - Upload to client's "03 — Final Documents" folder
  - Right-click → Share → Change to "Anyone with the link — Viewer"
  - Copy link and send to client
  - After 30 days, revoke public access
- Only you should have Editor access to the entire structure
- Do not share the root DASTAWAIZ folder with anyone

---

## STEP BY STEP — HOW TO CREATE A NEW CLIENT FOLDER:

When you receive a new paid matter:

1. Open Google Drive
2. Navigate to: DASTAWAIZ → DASTAWAIZ Clients → 2026
3. Click "New" → "New Folder"
4. Name it: DA-2026-00XX — [Client First Name Last Name]
   Example: DA-2026-0001 — Ali Ahmed
5. Open that folder
6. Create 4 subfolders:
   - 01 — Original Documents
   - 02 — Working Drafts
   - 03 — Final Documents
   - 04 — Communications
7. If client uploaded a document via Google Form:
   - Find it in Google Drive (Forms automatically save uploads)
   - Move it to: DA-2026-00XX → 01 — Original Documents
8. Copy the folder URL and paste it into your Google Sheet → Column R (Drive Folder Link)

# DASTAWAIZ — Complete Step-by-Step Setup Instructions
# Do everything in this exact order

---

## DAY 1 — GOOGLE SHEETS CRM (30 minutes)

### STEP 1: Create the Google Sheet

1. Go to sheets.google.com
2. Click "Blank spreadsheet"
3. Rename it: DASTAWAIZ CRM (click on "Untitled spreadsheet" at top left)

### STEP 2: Create these tabs (click + at bottom to add sheets)

Rename tabs to:
- LEADS
- MATTER ID TRACKER
- EMAIL TEMPLATES
- PRICING REFERENCE
- STATUS REFERENCE

### STEP 3: Set up LEADS tab — paste these headers in Row 1

Click cell A1 and paste each header in order:
A1: Matter ID
B1: Date Received
C1: Client Name
D1: WhatsApp Number
E1: Email Address
F1: Service Type
G1: Document Type
H1: Jurisdiction
I1: Urgency
J1: Lead Source
K1: Status
L1: Notes / Special Requirements
M1: Quote Amount (PKR)
N1: Quote Sent Date
O1: Payment Status
P1: Payment Reference
Q1: Payment Date
R1: Drive Folder Link
S1: AI Draft Done
T1: Human Review Done
U1: QC Done
V1: Delivery Date
W1: Follow-Up Done
X1: Cross-Sell Opportunity
Y1: Referred To
Z1: Repeat Client

### STEP 4: Make Row 1 bold and freeze it
- Select Row 1 (click the "1" on the left)
- Press Ctrl+B (bold)
- Go to View → Freeze → 1 row

### STEP 5: Add dropdown validation for Status column (Column K)
- Click on K2
- Hold Shift and click K1000 (selects the column range)
- Go to Data → Data validation
- Criteria: List of items
- Paste: New Lead,Under Review,Info Needed,Quote Sent,Awaiting Payment,Paid,In Progress,Human Review,QC,Ready to Deliver,Delivered,Completed,Follow-Up Done,Closed,Referred — BTaxFiler,Referred — Mr. Laws,Declined
- Save

### STEP 6: Set up MATTER ID TRACKER tab
- A1: Label
- B1: Value
- A2: Last Matter Number
- B2: 0
- A3: Current Year
- B3: 2026
- A4: Next ID
- B4: =MATTER ID TRACKER!B3&"-"&TEXT(MATTER ID TRACKER!B2+1,"0000")

### STEP 7: Color code the sheet
- Select Row 1 → Fill color: Dark navy or dark teal
- Change Row 1 text color to white
- This makes it look professional

---

## DAY 1 — GOOGLE DRIVE (20 minutes)

1. Go to drive.google.com
2. Create folder: DASTAWAIZ (main)
3. Inside it, create: DASTAWAIZ Clients
4. Inside that, create: 2026
5. Go back to main DASTAWAIZ folder
6. Create: DASTAWAIZ Internal
7. Inside Internal, create these folders:
   - Templates
   - Checklists
   - Email Templates
   - Pricing
   - Claude Prompts
8. Create: DASTAWAIZ Website
9. Inside Website create: Images, Logo Files, Blog Drafts

---

## DAY 1 — GOOGLE FORMS — Form 1: Contract Creation (45 minutes)

1. Go to forms.google.com
2. Click "Blank form"
3. Title: Create My Contract — DASTAWAIZ
4. Description: Tell us about the document you need. We will review your request and send you a quotation within 24 hours.

**Add questions exactly as listed in the google_forms_spec.md file**

After adding all questions:
5. Click Settings (gear icon at top)
6. Under "Responses": Turn on "Collect email addresses"
7. Turn on "Send responders a copy of their response"
8. Click "Presentation" tab: Add confirmation message from spec
9. Click Responses tab → Green Sheets icon → Create new spreadsheet → Name: DASTAWAIZ CRM Form Responses

---

## DAY 2 — GOOGLE FORMS — Forms 2 & 3 (60 minutes)

Repeat the same process for:
- Form 2: Review My Contract
- Form 3: Ask a Legal Question

For Form 2 — File Upload question:
- Add question → type "File upload"
- Google will ask to confirm — click Continue
- Set: Allow only specific file types → PDF, Word
- Maximum file size: 10 MB
- Maximum files: 1

---

## DAY 2 — APPS SCRIPT SETUP (30 minutes)

1. Open your DASTAWAIZ CRM Google Sheet
2. Click Extensions → Apps Script
3. Delete everything in the editor
4. Copy the entire content from apps_script_crm.js
5. Paste it into the editor
6. Find line: const ADMIN_EMAIL = "YOUR_GMAIL_HERE@gmail.com";
7. Replace with your actual Gmail address
8. Click Save (disk icon)
9. Click Run → select "onOpen" → authorize when prompted
10. Go back to your Google Sheet — you should see a "DASTAWAIZ" menu at top

### Connect Form to Script:
1. Open Google Form 1
2. Click Responses tab
3. Click 3 dots (more options) → Script editor — this opens Apps Script linked to the form
4. OR: In your Sheet's Apps Script, go to Triggers (clock icon on left)
5. Click "Add Trigger"
6. Function: onFormSubmit
7. Event source: From spreadsheet
8. Event type: On form submit
9. Save

Test it: Submit a test response on your form and check if:
- Row appears in LEADS sheet
- You receive admin email
- Client receives acknowledgment email

---

## DAY 3 — WHATSAPP BUSINESS SETUP (30 minutes)

1. Download WhatsApp Business app on your phone
2. Set up with your business number (different from personal if possible)
3. Go to Settings → Business Settings:
   - Business name: DASTAWAIZ
   - Business category: Professional Services / Legal Services
   - Description: Professional legal document services. Create and review contracts. Serving Pakistan.
   - Address: Lahore, Pakistan (optional)
   - Email: your email
   - Website: dastawaiz.com (add later)
4. Set up Away Message:
   "Thank you for contacting DASTAWAIZ. We have received your message and will respond within a few hours during business hours (Mon–Sat, 9am–6pm PKT). For new requests, please submit via: [Form Link]"
5. Set up Quick Replies (Settings → Business Tools → Quick Replies):
   - /ack — "Thank you for contacting DASTAWAIZ. Your matter has been noted and we will respond shortly."
   - /quote — "We have reviewed your request. Please see your quotation below:"
   - /pay — "Payment instructions: Bank: [details] / Easypaisa: [number] / JazzCash: [number]"
   - /done — "Your document is ready. Please find it at the link below:"

---

## DAY 3 — GOOGLE BUSINESS PROFILE (30 minutes)

1. Go to business.google.com
2. Click "Manage now" / "Add your business"
3. Business name: DASTAWAIZ
4. Business category: Legal Services / Document Preparation Service
5. Location: Lahore, Pakistan (or mark as service-area business if fully remote)
6. Phone: Your WhatsApp Business number
7. Website: dastawaiz.com (add later)
8. Description (max 750 chars):
   "DASTAWAIZ is Pakistan's professional legal document service. We create and review contracts, agreements and legal documents for businesses, freelancers, startups and individuals. Services include NDA drafting, employment agreements, freelancer contracts, software development agreements, partnership agreements and contract review. Every document is human-reviewed. Fully remote. Serving Pakistan and overseas Pakistanis."
9. Verify via postcard or phone

---

## DAY 4 — SOCIAL MEDIA SETUP (60 minutes)

### LinkedIn Page
1. linkedin.com → Work → Create a Company Page
2. Name: DASTAWAIZ
3. URL: linkedin.com/company/dastawaiz
4. Industry: Legal Services
5. Company size: 1–10
6. Tagline: Legal Documents. Made Simple.
7. Description: [Use Google Business description above]
8. Logo: [Create using Canva — see below]

### Instagram
1. Create new account: @dastawaiz or @dastawaiz.pk
2. Switch to Professional → Business
3. Category: Legal Service
4. Bio (150 chars max):
   "📄 Legal Documents. Made Simple.
   NDA | Contracts | Agreements
   Pakistan 🇵🇰 | Fully Remote
   👇 Create or Review Your Contract"
5. Link: Google Form link (until website is live)

### Facebook Page
1. facebook.com → Create Page
2. Name: DASTAWAIZ
3. Category: Legal Services
4. Description: Same as Google Business

---

## DAY 4 — CANVA LOGO/BRANDING (60 minutes)

1. Go to canva.com (free account)
2. Create new design → Logo
3. DASTAWAIZ brand guidelines:
   - Colors: Deep navy (#1B2A4A) + Gold/Amber (#C9A84C) + White
   - Font: Playfair Display (heading) + Inter or Lato (body)
   - Style: Clean, professional, minimal

4. Create these assets in Canva:
   - Logo (square version for social)
   - Logo (horizontal version for website header)
   - Profile picture (just the icon/monogram)
   - Social media post template (1080x1080)
   - Story template (1080x1920)

---

## DAYS 5–7 — CONTENT CREATION

Use the blog posts and page content from the files provided.
Draft the 5 blog posts in Google Docs.
Store in: DASTAWAIZ → DASTAWAIZ Website → Blog Drafts

These are ready to publish the moment WordPress is live.

---

## SOFT LAUNCH CHECKLIST (Before Going Live)

- [ ] Google Sheets CRM ready and tested
- [ ] All 3 Google Forms created and tested
- [ ] Form → Sheet automation working
- [ ] Admin email notification working
- [ ] Client acknowledgment email working
- [ ] Google Drive folder structure created
- [ ] WhatsApp Business set up with quick replies
- [ ] Google Business Profile created
- [ ] LinkedIn page created
- [ ] Instagram created
- [ ] Logo created in Canva
- [ ] 5 blog posts drafted
- [ ] All page content ready
- [ ] Internal Claude prompts saved and tested
- [ ] QC checklist in Google Drive
- [ ] Email templates in Google Drive
- [ ] Pricing reference in Google Drive

Once all above are done:
→ Share Google Form links on WhatsApp, LinkedIn, Instagram
→ Tell BTaxFiler contacts about DASTAWAIZ
→ Tell Mr. Laws contacts
→ You are LIVE — taking real clients

# DASTAWAIZ — Internal Claude Workflow Prompts

Use these prompts yourself inside Claude Pro.
Copy the prompt, fill in the [BRACKETS], paste and run.
Never share AI output directly with client — always review first.

---

## PROMPT 1: CONTRACT DRAFTING

```
You are an experienced contracts lawyer drafting a legal document for a Pakistan-based legal document service called DASTAWAIZ.

CLIENT DETAILS:
- Client name / description: [NAME/DESCRIPTION]
- Client type: [Individual / Business / Startup / etc.]
- Document type: [DOCUMENT TYPE]
- Party A: [NAME AND ROLE e.g. "Ali Ahmed, Service Provider"]
- Party B: [NAME AND ROLE e.g. "XYZ Company, Client"]
- Purpose: [BRIEF PURPOSE]
- Key commercial terms: [PAYMENT, DURATION, DELIVERABLES etc.]
- Jurisdiction: [Pakistan / UAE / UK / Other]
- Special requirements: [ANY SPECIFIC CLAUSES REQUESTED]
- Urgency: [Standard / Urgent]

INSTRUCTIONS:
1. Draft a complete, professionally structured [DOCUMENT TYPE]
2. Apply [JURISDICTION] law as the governing law
3. Include all standard protective clauses appropriate for this document type
4. Use clear, professional English
5. Number all clauses
6. Include: definitions, main obligations, payment terms, term and termination, confidentiality (if appropriate), IP ownership (if appropriate), liability limitation, indemnity, governing law, dispute resolution, general/boilerplate
7. After the draft, list any clauses you have flagged as requiring client clarification or human review
8. Do not include any legal advice disclaimers in the body of the contract itself

Draft the complete document now.
```

---

## PROMPT 2: CONTRACT REVIEW / VETTING

```
You are a contracts professional reviewing a legal document for a client of DASTAWAIZ, a Pakistan-based legal document service.

CLIENT CONTEXT:
- Client position in this agreement: [Party A / Party B / Employer / Employee / etc.]
- Client's main concern: [DESCRIBE CONCERN]
- Jurisdiction: [JURISDICTION]
- Document type: [DOCUMENT TYPE]

DOCUMENT TEXT:
[PASTE FULL DOCUMENT TEXT HERE]

REVIEW INSTRUCTIONS:
Analyse this document from the perspective of [CLIENT POSITION] and identify:

1. SUMMARY — What type of agreement is this and what does it do in plain English?

2. KEY OBLIGATIONS — What must my client do under this agreement?

3. KEY RIGHTS — What rights does my client have?

4. PAYMENT TERMS — What are the payment terms? Are they fair?

5. TERMINATION — How can this agreement be terminated? Is it balanced?

6. LIABILITY AND INDEMNITY — What liability does my client carry? Are there indemnity obligations?

7. CONFIDENTIALITY — Is confidentiality addressed? Is it appropriate?

8. INTELLECTUAL PROPERTY — Who owns any IP created? Is this appropriate for my client?

9. DISPUTE RESOLUTION — How are disputes resolved? Which court or arbitration?

10. GOVERNING LAW — Which law governs?

11. MISSING CLAUSES — What standard protections are absent that should be present?

12. ONE-SIDED CLAUSES — Identify any clauses that appear unfairly weighted against my client.

13. UNUSUAL OR RISKY CLAUSES — Flag anything unusual or potentially problematic.

14. NEGOTIATION POINTS — What 3–5 things should my client consider negotiating?

15. OVERALL RISK ASSESSMENT — Rate overall risk: Low / Medium / High and explain briefly.

Present your analysis clearly with numbered headings. Write in plain English. This analysis will be reviewed by a human professional before being sent to the client.
```

---

## PROMPT 3: LEGAL QUESTION RESPONSE

```
You are a professional legal document consultant at DASTAWAIZ, a Pakistan-based legal document and contract service.

CLIENT QUESTION:
- Question type: [DESCRIBE]
- Document type involved: [TYPE]
- Jurisdiction: [JURISDICTION]
- Client situation: [DESCRIBE IN DETAIL]
- Document text (if uploaded): [PASTE RELEVANT CLAUSES OR FULL TEXT]

INSTRUCTIONS:
Provide a clear, professional written response to this client's question.

Your response should:
1. Directly address the specific question asked
2. Explain the relevant legal position in plain English
3. Identify any risks or issues the client should be aware of
4. Where appropriate, suggest practical steps the client can take
5. Where the matter requires professional legal engagement beyond document services (e.g. court proceedings, formal legal advice), clearly state this
6. Do NOT guarantee any legal outcome
7. Do NOT claim to be a lawyer or law firm
8. Keep the response concise and practical

This response will be reviewed by a human professional before being sent to the client.
```

---

## PROMPT 4: QUALITY CONTROL CHECK

```
You are performing a final quality control check on a legal document prepared by DASTAWAIZ before client delivery.

DOCUMENT DETAILS:
- Document type: [TYPE]
- Client: [NAME]
- Matter ID: [DA-2026-XXXX]
- Jurisdiction: [JURISDICTION]

DOCUMENT TEXT:
[PASTE FULL DOCUMENT]

QUALITY CONTROL CHECKLIST:
Check each of the following and report any issues found:

1. PARTY NAMES — Are all party names consistent throughout the document?
2. DATES — Are all dates correct and consistent?
3. DEFINED TERMS — Are all defined terms used consistently?
4. CLAUSE REFERENCES — Are all internal clause references correct?
5. PAYMENT TERMS — Are payment amounts, dates and methods clearly stated?
6. TERMINATION — Is the termination clause present and clearly worded?
7. GOVERNING LAW — Is the governing law clause present and correct?
8. DISPUTE RESOLUTION — Is the dispute resolution clause present?
9. CONFIDENTIALITY — Is confidentiality addressed appropriately?
10. IP CLAUSES — Is intellectual property ownership addressed (if relevant)?
11. SIGNATURES — Is the signature block correctly formatted for all parties?
12. FORMATTING — Is the document consistently formatted and professionally presented?
13. SPELLING — Are there any spelling errors?
14. MISSING STANDARD CLAUSES — Are there any obvious standard clauses missing?
15. INTERNAL INCONSISTENCIES — Are there any contradictions within the document?

Provide a PASS / ISSUE report for each item.
List all issues clearly.
If no issues: confirm the document is ready for delivery.
```

---

## PROMPT 5: MATTER ID EMAIL GENERATOR

```
Generate a professional email for DASTAWAIZ for the following purpose:

Email type: [Acknowledgment / Quote / Payment Confirmed / Delivery / Follow-up / Info Required]
Matter ID: [DA-2026-XXXX]
Client name: [NAME]
Document type: [TYPE]
Key details: [RELEVANT DETAILS e.g. amount, date, drive link]

Write a concise, professional email. 
Sign off as "DASTAWAIZ Team".
Do not include legal advice.
Keep it brief and clear.
```

---

## DAILY ADMIN PROMPT (Optional — 5 mins each morning)

```
I run a legal document service called DASTAWAIZ.

Here are my current open matters from my Google Sheet:

[PASTE YOUR OPEN MATTERS TABLE — Matter ID, Client, Service, Status, Notes]

Help me prioritize today's tasks.
Tell me:
1. What needs immediate action today?
2. What follow-ups are due?
3. Any matters that have been open too long?
4. Suggested actions for each open matter.

Keep it brief and practical.
```

# DASTAWAIZ — Complete Website Page Content

---

## PAGE 1: HOMEPAGE

**Meta Title:** DASTAWAIZ — Legal Documents Made Simple | Pakistan
**Meta Description:** Create, review and protect your contracts with DASTAWAIZ. Professional legal documents, human-reviewed, delivered digitally. Serving Pakistan.

---

### HERO SECTION

**Headline:**
Legal Documents.
Made Simple.

**Subheadline:**
Create contracts, review agreements and get professional legal document assistance — without expensive law firm fees.

**Three CTA Buttons:**
[Create My Contract]  [Review My Agreement]  [Ask a Legal Question]

**Trust line below buttons:**
✓ Human-reviewed  ✓ Confidential  ✓ Delivered digitally  ✓ Pakistan-based

---

### HOW IT WORKS (3 steps)

**Step 1 — Tell Us What You Need**
Submit a simple form describing your document requirement or upload your existing agreement.

**Step 2 — We Prepare or Review**
Our team reviews your submission, prepares your document and sends you a quotation. Every document is human-reviewed before delivery.

**Step 3 — Receive Your Document**
Once payment is confirmed, your professionally prepared document is delivered to your email and accessible via a secure link.

---

### THREE SERVICE CARDS

**Card 1 — Create a Contract**
Need a professionally drafted agreement? We create NDAs, employment agreements, freelancer contracts, software agreements and more — tailored to your specific situation.
[Create My Contract →]

**Card 2 — Review My Agreement**
Received a contract you are not sure about? Upload it and our team will identify risks, missing clauses and provide written recommendations.
[Review My Agreement →]

**Card 3 — Ask a Legal Question**
Have a question about a contract clause, your rights or your obligations? Submit your question and receive a clear written response.
[Ask a Legal Question →]

---

### WHO WE SERVE

- Freelancers and independent consultants
- IT companies and software houses
- Startups and growing businesses
- E-commerce sellers
- Employers and employees
- Landlords and tenants
- Agencies and service providers

---

### WHY DASTAWAIZ

✓ **Professional Quality** — Every document is prepared and reviewed by qualified professionals

✓ **Affordable** — Significantly more affordable than traditional law firm fees

✓ **Fast** — Standard turnaround 5–7 working days. Urgent options available.

✓ **Confidential** — Your documents are handled with strict confidentiality

✓ **Digital** — Fully remote service. No office visit required.

✓ **Pakistan-based** — We understand Pakistani business practices and law

---

### POPULAR DOCUMENTS

- NDA / Confidentiality Agreement — from PKR 2,500
- Freelancer Agreement — from PKR 3,500
- Employment Agreement — from PKR 4,000
- Software Development Agreement — from PKR 7,500
- Lease / Rent Agreement — from PKR 3,500
- Partnership Agreement — from PKR 10,000
[View All Documents →]

---

### FOOTER CTA
**Ready to protect your business?**
[Create My Contract]  [Review My Agreement]

---
---

## PAGE 2: HOW IT WORKS

**Meta Title:** How DASTAWAIZ Works — Simple Legal Document Service
**Meta Description:** Learn how DASTAWAIZ creates and reviews legal documents. Simple 3-step process, human-reviewed, delivered digitally.

---

### HEADLINE
Simple. Professional. Delivered.

### SUBHEADLINE
DASTAWAIZ makes professional legal documents accessible to every business, freelancer and individual in Pakistan.

---

### PATH A — CREATING A CONTRACT

**Step 1 — Submit Your Request**
Complete our simple form. Tell us what type of document you need, who the parties are, the purpose and any specific requirements. This takes approximately 3–5 minutes.

**Step 2 — We Send You a Quotation**
Our team reviews your submission within 24 hours and sends a fixed-price quotation. No hidden charges.

**Step 3 — Confirm and Pay**
Confirm the quotation and pay via bank transfer, Easypaisa, JazzCash or Raast.

**Step 4 — We Prepare Your Document**
Our team prepares your document using your specific information. Every document is human-reviewed for accuracy, completeness and commercial appropriateness.

**Step 5 — Delivery**
Your completed document is delivered to your email as a professional PDF, with an editable version where appropriate.

**Step 6 — One Revision Included**
Standard packages include one reasonable revision within 7 days of delivery.

---

### PATH B — CONTRACT REVIEW

**Step 1 — Upload Your Document**
Upload your agreement in PDF, DOC or DOCX format. Tell us your position in the agreement and your main concern.

**Step 2 — Quotation**
We review your upload and send a quotation within 24 hours.

**Step 3 — Professional Review**
Our team reviews the document in detail — identifying risks, unusual obligations, missing protections and areas for negotiation.

**Step 4 — Written Report**
You receive a clear written review with specific comments, risk flags and recommended amendments.

---

### PATH C — LEGAL QUESTION

**Step 1 — Describe Your Situation**
Submit your question and provide relevant context. Optionally upload a document.

**Step 2 — Written Response**
We provide a clear, written response addressing your specific question. Where the matter requires more detailed professional engagement, we will advise you accordingly.

---

### IMPORTANT NOTICES

**About AI**
DASTAWAIZ uses AI tools internally to assist with document analysis and drafting. All documents are human-reviewed before delivery. AI-generated content is never sent directly to clients without professional review.

**Professional Review**
DASTAWAIZ provides legal document preparation and review services. Our responses represent professional guidance based on the information you provide. For matters involving litigation, court proceedings or regulated legal practice, we will advise you to engage a qualified advocate.

---
---

## PAGE 3: CONTRACT CREATION

**Meta Title:** Contract Drafting Service Pakistan — DASTAWAIZ
**Meta Description:** Get professionally drafted contracts and legal agreements for your business. NDA, employment, freelancer, software and more. Pakistan-based. Affordable.

---

### HEADLINE
Create Your Contract

### SUBHEADLINE
Tell us what you need. We prepare it professionally, review it thoroughly and deliver it to you digitally.

[Create My Contract — Start Now →]

---

### POPULAR CONTRACT TYPES

**For Freelancers & Consultants**
- Freelancer Service Agreement
- Consultancy Agreement
- NDA / Confidentiality Agreement
- Independent Contractor Agreement

**For Businesses & Employers**
- Employment Agreement
- Vendor / Supplier Agreement
- Service Agreement
- Agency Agreement
- Commission Agreement

**For Startups**
- Partnership Agreement
- Shareholders Agreement
- IP Assignment Agreement
- Co-Founder Agreement

**For IT & Software Companies**
- Software Development Agreement
- Software Licensing Agreement
- IT Service Agreement
- Maintenance & Support Agreement

**For Property**
- Residential Lease Agreement
- Commercial Lease Agreement
- Rent Agreement

**For E-commerce & Online Business**
- Terms & Conditions
- Privacy Policy
- E-commerce Supplier Agreement
- Return & Refund Policy

**Other**
- MOU (Memorandum of Understanding)
- Loan Agreement
- Settlement Agreement
- Custom / Any other document

[Request a Document Not Listed Above →]

---

### WHAT IS INCLUDED

✓ Professionally drafted document based on your specific situation
✓ Correct legal structure for Pakistani law (or specified jurisdiction)
✓ Standard protective clauses included
✓ Clear, readable language
✓ One reasonable revision included
✓ Delivered as PDF + editable DOCX

---
---

## PAGE 4: CONTRACT REVIEW

**Meta Title:** Contract Review Service Pakistan — DASTAWAIZ
**Meta Description:** Have your agreement professionally reviewed. Identify risks, missing clauses and negotiate with confidence. Pakistan contract review service.

---

### HEADLINE
Review My Agreement

### SUBHEADLINE
Received a contract you are not sure about? Our team reviews it thoroughly and tells you exactly what it means, what risks you carry and how to protect yourself.

[Upload My Document →]

---

### WHAT WE REVIEW

- Are the parties correctly identified?
- Is the payment structure fair and clear?
- Are the termination rights balanced?
- What liability do you carry?
- Is there an indemnity clause against you?
- Is confidentiality protected?
- Who owns the intellectual property?
- What is the governing law?
- How are disputes resolved?
- Are there non-compete or restriction clauses?
- What happens if the other party breaches?
- Are there any unusual or one-sided obligations?
- What clauses are missing that should be present?
- What should you negotiate before signing?

---

### WHAT YOU RECEIVE

- Written review with clause-by-clause comments
- Risk flags clearly identified
- Missing clause recommendations
- Suggested amendments where appropriate
- Plain English explanation of complex terms

---

### WHO SHOULD USE THIS

- Before signing any significant business contract
- When you receive a standard form contract from a large company
- When you are an employee receiving an employment offer
- When you are a supplier or vendor being asked to sign terms
- When you are entering a partnership or joint venture
- When you are a tenant reviewing a commercial lease
- Whenever you feel uncertain about what you are signing

---
---

## PAGE 5: PRICING

**Meta Title:** Legal Document Prices — DASTAWAIZ Pakistan
**Meta Description:** Transparent, affordable pricing for contract drafting and review in Pakistan. Fixed prices for standard documents. No hidden fees.

---

### HEADLINE
Simple, Transparent Pricing

### SUBHEADLINE
No hidden fees. Fixed prices for standard documents. Custom quotations for complex matters.

---

### CONTRACT CREATION PRICING

| Document | Starting Price |
|---|---|
| NDA / Confidentiality Agreement | PKR 2,500 |
| Freelancer Agreement | PKR 3,500 |
| Employment Agreement | PKR 4,000 |
| Consultancy Agreement | PKR 4,000 |
| Lease / Rent Agreement | PKR 3,500 |
| Software Development Agreement | PKR 7,500 |
| Partnership Agreement | PKR 10,000 |
| Shareholders Agreement | PKR 12,000 |
| Other / Custom | Request Quote |

Urgent service (2–3 working days): +50% on standard price

---

### CONTRACT REVIEW PRICING

| Type | Starting Price |
|---|---|
| Standard Contract Review | PKR 4,000 |
| Complex Agreement Review | PKR 8,000+ |
| Same-day review | Request Quote |

---

### PACKAGES

**Freelancer Starter Pack**
NDA + Freelancer Agreement
PKR 5,500 (save PKR 500)

**Startup Legal Pack**
NDA + Partnership/Shareholders Agreement + Employment Agreement
PKR 14,000 (save PKR 2,000)

**IT Business Pack**
NDA + Software Dev Agreement + Service Agreement + Employment Agreement + Privacy Policy
PKR 22,000 (save PKR 3,500)

---

### PAYMENT METHODS
- Bank Transfer
- Easypaisa
- JazzCash
- Raast

---

### NOT SURE WHAT YOU NEED?
[Request a Custom Quote →] or [Ask a Legal Question →]

---
---

## PAGE 6: FAQ

**Meta Title:** Frequently Asked Questions — DASTAWAIZ Legal Documents
**Meta Description:** Answers to common questions about DASTAWAIZ legal document services, pricing, turnaround times and document delivery.

---

**Q: Is DASTAWAIZ a law firm?**
A: DASTAWAIZ is a legal document preparation and review service. We prepare and review contracts and legal documents professionally. For matters requiring court representation or formal legal practice, we will advise you accordingly.

**Q: Are your documents reviewed by humans?**
A: Yes. Every paid document or review is examined by our team before delivery. We use AI tools internally to assist with analysis and drafting, but no document is delivered to a client without human review.

**Q: How long does it take?**
A: Standard turnaround is 5–7 working days. Urgent service (2–3 days) is available at an additional fee. Same-day service is available subject to availability.

**Q: Is my document confidential?**
A: Absolutely. All documents are handled with strict confidentiality. We do not share your documents with any third party. Documents are stored in secure, access-restricted storage.

**Q: What file formats do you accept?**
A: We accept PDF, DOC and DOCX. Maximum file size is 10 MB.

**Q: What file formats do you deliver?**
A: Final documents are delivered as PDF. Editable DOCX versions are included for standard drafting services.

**Q: Can I request amendments after delivery?**
A: Yes. Standard packages include one reasonable revision within 7 days of delivery. Major structural changes after delivery may require an additional fee.

**Q: Which jurisdictions do you cover?**
A: We primarily serve Pakistani clients and draft under Pakistani law. We can also prepare documents under UAE, UK and general international commercial law. Always specify your jurisdiction when submitting a request.

**Q: How do I pay?**
A: We accept payment via bank transfer, Easypaisa, JazzCash and Raast. Payment instructions are included in your quotation.

**Q: What if I need something not listed on your website?**
A: Submit a custom request and we will advise whether we can assist and provide a quotation.

**Q: Can DASTAWAIZ help with disputes or going to court?**
A: DASTAWAIZ prepares and reviews documents. For active disputes, litigation or court matters, we will refer you to an appropriate legal professional.

**Q: Do you serve clients outside Pakistan?**
A: Yes. Overseas Pakistanis and foreign businesses requiring documents governed by Pakistani law are welcome. We operate fully remotely.

---
---

## PAGE 7: LEGAL DISCLAIMER PAGE

**Meta Title:** Legal Disclaimer — DASTAWAIZ

---

### LEGAL DISCLAIMER

**Important — Please Read Before Using Our Services**

**1. Not a Law Firm**
DASTAWAIZ is a legal document preparation and professional review service. It is not a law firm and does not practice law. Use of this website or our services does not create a solicitor-client or lawyer-client relationship.

**2. Not Legal Advice**
The content on this website, including blog posts, articles, general information, document templates and AI-assisted responses, is provided for general informational and educational purposes only. It does not constitute legal advice and should not be relied upon as such.

**3. Professional Review**
Our paid document services are reviewed by qualified professionals before delivery. However, every legal situation is unique. We strongly recommend that for significant commercial transactions, employment matters, property transactions or any matter involving substantial rights or obligations, you also seek independent legal advice.

**4. AI Disclaimer**
DASTAWAIZ uses artificial intelligence tools to assist with document analysis, drafting and review internally. AI-generated content is always reviewed by our team before delivery. AI is not a substitute for professional legal judgment.

**5. No Guaranteed Outcomes**
DASTAWAIZ makes no representations or warranties regarding the legal validity, enforceability or commercial suitability of any document prepared or reviewed. Legal outcomes depend on many factors outside our control.

**6. Jurisdiction**
Our services are primarily designed for documents governed by Pakistani law. For documents governed by foreign law, we will advise you of any limitations.

**7. Confidentiality**
We maintain the confidentiality of all documents submitted. See our Privacy Policy for full details.

**8. Limitation of Liability**
DASTAWAIZ's liability in respect of any service is limited to the fee paid for that specific service.

---
---

## PAGE 8: AI DISCLAIMER

**Meta Title:** AI Disclaimer — DASTAWAIZ

---

### AI DISCLAIMER

DASTAWAIZ uses artificial intelligence technology as an internal tool to assist with document analysis, drafting and review.

**What AI does at DASTAWAIZ:**
- Assists our team in analysing and summarising submitted documents
- Helps identify common clause types and structures
- Supports drafting by generating initial document frameworks
- Helps identify potentially missing or unusual provisions

**What AI does NOT do at DASTAWAIZ:**
- AI does not communicate directly with clients in relation to paid services
- AI does not provide final legal conclusions without human review
- AI does not replace the professional judgment of our review team
- AI is not a licensed lawyer and cannot practice law
- AI analysis is preliminary only and is always reviewed before client delivery

**Important:**
Artificial intelligence tools, including large language models, can make errors. DASTAWAIZ takes responsibility for the quality of its professional services through human review and quality control. If you have concerns about the AI processing of your documents, please contact us before submitting.

**Your Consent:**
By submitting a document or request to DASTAWAIZ, you consent to your submission being processed using AI tools as part of our internal review and preparation process, subject to our Privacy Policy.

---

# DASTAWAIZ — 5 Launch Blog Posts (SEO Optimized)

---

## BLOG POST 1

**URL Slug:** /blog/freelancer-agreement-pakistan
**Meta Title:** Freelancer Agreement in Pakistan — What You Must Include (2026)
**Meta Description:** Every Pakistani freelancer needs a proper service agreement. Here's exactly what to include to protect your payment and your work.
**Target Keyword:** freelancer agreement Pakistan
**Word Count Target:** 900–1100 words

---

**HEADLINE:** Freelancer Agreement in Pakistan — What You Must Include to Protect Yourself

**INTRODUCTION:**
If you are a freelancer in Pakistan working with local or international clients, you are taking a significant legal risk without a proper written agreement.

A verbal agreement, WhatsApp conversation or email exchange is not enough. When a client refuses to pay, changes the scope of work or claims ownership of your work, a written freelancer agreement is the only thing that protects you.

This article explains exactly what every freelancer agreement in Pakistan should include.

---

**SECTION 1: What Is a Freelancer Agreement?**

A freelancer agreement (also called a service agreement or independent contractor agreement) is a written contract between a freelancer and their client that clearly sets out:

- What work you will deliver
- How much you will be paid and when
- Who owns the work once completed
- What happens if either party wants to end the arrangement
- How disputes are resolved

Without this agreement, you are relying entirely on trust — which, as many Pakistani freelancers have discovered, is not enough.

---

**SECTION 2: 7 Things Every Pakistani Freelancer Agreement Must Include**

**1. Clear Description of Services**
Describe exactly what you are delivering. Vague descriptions lead to scope creep. Specify: deliverables, format, revisions included and what is excluded.

**2. Payment Terms**
State the exact amount, payment schedule (upfront, milestone, completion), payment method (bank transfer, Payoneer, etc.) and what happens if payment is late.

**3. Intellectual Property Ownership**
Who owns the work after you deliver it? By default in Pakistan, the creator retains IP unless specifically transferred. Your agreement must be clear on this.

**4. Revision Policy**
How many revisions are included? What counts as a major revision requiring additional payment?

**5. Confidentiality**
If you will access confidential business information, a confidentiality clause protects both parties.

**6. Termination Rights**
Under what circumstances can either party end the agreement? What happens to work in progress and payments already made?

**7. Governing Law and Dispute Resolution**
Which country's law applies? How will disputes be resolved — negotiation, arbitration or courts?

---

**SECTION 3: Common Mistakes Pakistani Freelancers Make**

- Starting work before signing an agreement
- Relying on email confirmations as contracts
- Not including a payment schedule — delivering everything before receiving payment
- Not specifying IP ownership — leading to disputes over who can use the work
- Using a template downloaded from the internet that is not suitable for Pakistani law

---

**SECTION 4: Do You Need a Lawyer to Draft a Freelancer Agreement?**

For most standard freelance arrangements, a properly drafted agreement from a professional document service is sufficient. You do not necessarily need a full law firm for a standard freelancer contract.

DASTAWAIZ specializes in preparing professionally drafted freelancer agreements tailored to Pakistani freelancers and their clients, at a fraction of traditional legal costs.

**[Get Your Freelancer Agreement Drafted — Starting PKR 3,500 →]**

---

**CONCLUSION:**
Every piece of work you deliver without a written agreement is a risk. A properly drafted freelancer agreement takes one day to prepare and protects you for the entire duration of your work relationship.

Do not wait until a dispute arises to realize you needed one.

---
---

## BLOG POST 2

**URL Slug:** /blog/nda-pakistan
**Meta Title:** NDA in Pakistan — Non-Disclosure Agreement Guide (2026)
**Meta Description:** What is an NDA? Do you need one in Pakistan? What should it include? Complete guide for businesses, startups and freelancers.
**Target Keyword:** NDA Pakistan
**Word Count Target:** 800–1000 words

---

**HEADLINE:** NDA in Pakistan — Everything You Need to Know Before Sharing Confidential Information

**INTRODUCTION:**
Before sharing a business idea, product design, client list, source code or any sensitive business information with another party — you need an NDA.

A Non-Disclosure Agreement (NDA) is one of the most commonly needed but frequently overlooked legal documents in Pakistan's business landscape.

This guide tells you exactly what an NDA is, when you need one and what it must include to actually protect you.

---

**SECTION 1: What Is an NDA?**

An NDA — also called a Confidentiality Agreement — is a legal contract in which one or more parties agree not to disclose certain confidential information to third parties.

It creates a legal obligation of confidentiality. If the other party breaches it, you have legal remedies.

---

**SECTION 2: When Do You Need an NDA in Pakistan?**

You need an NDA before:

- Sharing a business idea or startup concept with a potential co-founder or investor
- Hiring a developer, designer or contractor who will access proprietary information
- Entering into any business discussion where sensitive information will be exchanged
- Sharing client lists, pricing data, technical specifications or trade secrets
- Entering any joint venture discussion
- When an employee will have access to sensitive business information

---

**SECTION 3: Types of NDA**

**Unilateral NDA:** Only one party is disclosing confidential information. The other party is bound to keep it confidential. Used when hiring contractors or sharing your idea with investors.

**Mutual NDA:** Both parties are sharing confidential information with each other. Used when two businesses are exploring a partnership.

---

**SECTION 4: What Must a Pakistani NDA Include?**

1. **Definition of Confidential Information** — Be specific. What exactly is confidential?
2. **Obligations of the Receiving Party** — What must they do (and not do) with the information?
3. **Exclusions** — What information is NOT covered (e.g. information already in the public domain)?
4. **Duration** — How long does the obligation of confidentiality last?
5. **Remedies for Breach** — What happens if the NDA is violated?
6. **Governing Law** — Which law applies? (Pakistan, UAE, UK, etc.)
7. **Return or Destruction of Information** — Must confidential materials be returned when the relationship ends?

---

**SECTION 5: Can You Use a Free NDA Template?**

You can — but generic templates downloaded from foreign websites may not be enforceable under Pakistani law, may use terminology that does not apply in your situation and may have gaps that leave you unprotected.

A properly drafted NDA tailored to your specific situation and Pakistani law provides much stronger protection.

**[Get Your NDA Drafted — Starting PKR 2,500 →]**

---

## BLOG POST 3

**URL Slug:** /blog/employment-agreement-pakistan
**Meta Title:** Employment Agreement in Pakistan — Employer's Complete Guide (2026)
**Meta Description:** Every employer in Pakistan needs a written employment agreement. Here's what it must include under Pakistani employment law.
**Target Keyword:** employment agreement Pakistan

**HEADLINE:** Employment Agreement in Pakistan — What Every Employer Must Include

**INTRODUCTION:**
Hiring someone without a written employment agreement is one of the most common and costly legal mistakes Pakistani employers make.

When an employment dispute arises — and they do — the absence of a written contract leaves the employer in a very difficult position.

This guide explains exactly what a Pakistani employment agreement must include to protect your business.

---

**KEY SECTIONS TO COVER:**
- Job title and description
- Compensation and benefits
- Working hours
- Leave entitlements (under Pakistani labor law)
- Probation period
- Confidentiality
- Non-compete (enforceability considerations in Pakistan)
- Termination and notice period
- Governing law
- EOBI and SESSI obligations

**CTA:** [Get Your Employment Agreement — Starting PKR 4,000 →]

---

## BLOG POST 4

**URL Slug:** /blog/contract-review-red-flags
**Meta Title:** 7 Red Flags in Any Business Contract You Must Never Ignore
**Meta Description:** Before signing any business agreement, check for these 7 warning signs that could cost your business dearly.
**Target Keyword:** contract review Pakistan / red flags in business contracts

**HEADLINE:** 7 Red Flags in Any Business Contract You Must Never Ignore

**KEY POINTS:**
1. Unlimited liability clause
2. One-sided termination rights
3. Automatic renewal without notice
4. Unclear payment terms
5. No IP ownership clause
6. Foreign jurisdiction clause (you'd have to sue abroad)
7. Indemnity clause covering third party claims

**CTA:** [Have Your Contract Reviewed — Starting PKR 4,000 →]

---

## BLOG POST 5

**URL Slug:** /blog/software-development-agreement-pakistan
**Meta Title:** Software Development Agreement Pakistan — IT Companies & Clients Guide
**Meta Description:** Pakistani IT companies and their clients need a proper software development agreement. Here's what it must include to protect both sides.
**Target Keyword:** software development agreement Pakistan

**HEADLINE:** Software Development Agreement in Pakistan — Complete Guide for IT Companies and Clients

**KEY SECTIONS:**
- Scope of work and deliverables
- Payment milestones
- IP ownership (critical — who owns the code?)
- Source code escrow considerations
- Bug fixes and warranty period
- Confidentiality
- Non-solicitation
- Termination and IP on termination
- Governing law

**CTA:** [Get Your Software Development Agreement — Starting PKR 7,500 →]

---

