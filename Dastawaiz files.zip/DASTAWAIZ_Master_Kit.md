# ═══════════════════════════════════════════════════════════
# DASTAWAIZ — COMPLETE BUILD KIT
# Ahsan Awan, Advocate High Court
# dastawaizpk@gmail.com | +92 345 9477707
# ═══════════════════════════════════════════════════════════
# FILES IN THIS KIT:
# 1. Apps Script (copy-paste automation code)
# 2. CRM Sheet Setup (step-by-step)
# 3. Google Forms (all 3 forms, exact build)
# 4. Page & Social Content (all pages + 30 social posts)
# 5. Claude Internal Prompts (6 prompts)
# 6. Blog Posts (5 SEO posts, ready to publish)
# 7. Social Media Strategy (30 captions + hashtags)
# 8. Future App Blueprint (voice, upload, app roadmap)
# 9. 7-Day Action Plan (day by day, step by step)
# ═══════════════════════════════════════════════════════════

-e 


# ═══════ 01_apps_script.js ═══════
/**
 * DASTAWAIZ — Google Apps Script
 * ================================
 * HOW TO INSTALL:
 * 1. Open your DASTAWAIZ CRM Google Sheet
 * 2. Click Extensions → Apps Script
 * 3. Delete everything already there
 * 4. Paste this entire file
 * 5. Click Save (disk icon)
 * 6. Click Run → onOpen → authorize when Google asks
 * 7. Set up trigger: Triggers (clock icon) → Add Trigger →
 *    Function: onFormSubmit | Event: On form submit | Save
 */

const ADMIN_EMAIL = "dastawaizpk@gmail.com";
const ADMIN_WHATSAPP = "923459477707";
const SHEET_NAME = "LEADS";
const YEAR = "2026";

// ─────────────────────────────────────────────
// TRIGGERED ON EVERY FORM SUBMISSION
// ─────────────────────────────────────────────
function onFormSubmit(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const leadsSheet = ss.getSheetByName(SHEET_NAME);
  const trackerSheet = ss.getSheetByName("MATTER ID TRACKER");

  // Generate Matter ID
  let lastNum = Number(trackerSheet.getRange("B2").getValue()) || 0;
  let newNum = lastNum + 1;
  trackerSheet.getRange("B2").setValue(newNum);
  const matterId = "DA-" + YEAR + "-" + String(newNum).padStart(4, "0");

  // Read form values safely
  const r = e.namedValues || {};
  const get = (key) => (r[key] || [""])[0].trim();

  const clientName   = get("Full Name");
  const whatsapp     = get("WhatsApp Number");
  const email        = get("Email Address");
  const clientType   = get("Are you an individual or a business?");
  const serviceType  = get("Service Type");
  const docType      = get("What type of document do you need?") ||
                       get("What type of document are you uploading?") ||
                       get("What is your question about?");
  const jurisdiction = get("Jurisdiction / Country") || get("Which country / jurisdiction does this involve?");
  const urgency      = get("How urgently do you need this?") || "Standard (5–7 days)";
  const leadSource   = get("How did you find DASTAWAIZ?");
  const notes        = get("Additional Details / Requirements") ||
                       get("Briefly describe the parties involved") ||
                       get("Describe your situation and question in detail") ||
                       get("What is your main concern or question about this document?");

  const dateReceived = new Date();

  // Append to LEADS sheet
  leadsSheet.appendRow([
    matterId,        // A
    dateReceived,    // B
    clientName,      // C
    whatsapp,        // D
    email,           // E
    serviceType,     // F
    docType,         // G
    jurisdiction,    // H
    urgency,         // I
    leadSource,      // J
    "New Lead",      // K
    notes,           // L
    "",              // M Quote Amount
    "",              // N Quote Sent Date
    "Not Invoiced",  // O Payment Status
    "",              // P Payment Ref
    "",              // Q Payment Date
    "",              // R Drive Folder Link
    "No",            // S AI Draft Done
    "No",            // T Human Review Done
    "No",            // U QC Done
    "",              // V Delivery Date
    "No",            // W Follow-Up Done
    "",              // X Cross-Sell
    "",              // Y Referred To
    "No"             // Z Repeat Client
  ]);

  // Admin notification email
  GmailApp.sendEmail(
    ADMIN_EMAIL,
    "🔔 New DASTAWAIZ Lead — " + matterId + " — " + docType,
    "New lead received.\n\n" +
    "━━━━━━━━━━━━━━━━━━━━\n" +
    "MATTER ID: " + matterId + "\n" +
    "DATE: " + dateReceived.toLocaleString() + "\n" +
    "━━━━━━━━━━━━━━━━━━━━\n\n" +
    "CLIENT:\n" +
    "Name: " + clientName + "\n" +
    "WhatsApp: " + whatsapp + "\n" +
    "Email: " + email + "\n" +
    "Type: " + clientType + "\n\n" +
    "SERVICE:\n" +
    "Service: " + serviceType + "\n" +
    "Document: " + docType + "\n" +
    "Jurisdiction: " + jurisdiction + "\n" +
    "Urgency: " + urgency + "\n" +
    "Source: " + leadSource + "\n\n" +
    "NOTES:\n" + notes + "\n\n" +
    "━━━━━━━━━━━━━━━━━━━━\n" +
    "Open Google Sheet → update status to Under Review.\n" +
    "Reply to client within 24 hours.\n"
  );

  // Client acknowledgment email
  if (email) {
    GmailApp.sendEmail(
      email,
      "Your DASTAWAIZ Request — " + matterId,
      "Dear " + clientName + ",\n\n" +
      "Thank you for contacting DASTAWAIZ.\n\n" +
      "Your request has been received and assigned reference number: " + matterId + "\n\n" +
      "Our team will review your submission and respond within 24 hours with any questions or a quotation.\n\n" +
      "For urgent matters, you may also reach us on WhatsApp: +92 345 9477707\n\n" +
      "Please keep your reference number for all future correspondence.\n\n" +
      "Warm regards,\n" +
      "Ahsan Awan\n" +
      "Advocate High Court\n" +
      "DASTAWAIZ\n" +
      "dastawaizpk@gmail.com\n" +
      "WhatsApp: +92 345 9477707"
    );
  }
}

// ─────────────────────────────────────────────
// CREATE CLIENT FOLDER IN GOOGLE DRIVE
// Run from the DASTAWAIZ menu after selecting a row
// ─────────────────────────────────────────────
function createClientFolder() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);
  const ui = SpreadsheetApp.getUi();
  const row = sheet.getActiveCell().getRow();

  if (row <= 1) { ui.alert("Select a data row first."); return; }

  const matterId   = sheet.getRange(row, 1).getValue();
  const clientName = sheet.getRange(row, 3).getValue();

  if (!matterId || !clientName) {
    ui.alert("Matter ID or Client Name missing in this row.");
    return;
  }

  const rootName = "DASTAWAIZ Clients";
  const folderName = matterId + " — " + clientName;

  let rootFolder;
  const rf = DriveApp.getFoldersByName(rootName);
  rootFolder = rf.hasNext() ? rf.next() : DriveApp.createFolder(rootName);

  let yearFolder;
  const yf = rootFolder.getFoldersByName(YEAR);
  yearFolder = yf.hasNext() ? yf.next() : rootFolder.createFolder(YEAR);

  const clientFolder = yearFolder.createFolder(folderName);
  clientFolder.createFolder("01 — Original Documents");
  clientFolder.createFolder("02 — Working Drafts");
  clientFolder.createFolder("03 — Final Documents");
  clientFolder.createFolder("04 — Communications");

  const url = clientFolder.getUrl();
  sheet.getRange(row, 18).setValue(url); // Column R

  ui.alert("✅ Folder created!\n\n" + folderName + "\n\nLink saved in column R.");
}

// ─────────────────────────────────────────────
// ADDS DASTAWAIZ MENU TO SHEET
// ─────────────────────────────────────────────
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("⚖️ DASTAWAIZ")
    .addItem("Create Client Folder", "createClientFolder")
    .addToUi();
}
-e 


# ═══════ 02_crm_sheet_setup.md ═══════
# DASTAWAIZ CRM — Google Sheets Setup
# Exact step-by-step. Do this first.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 1 — CREATE THE SHEET
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Go to sheets.google.com (sign in as dastawaizpk@gmail.com)
2. Click the big "+" (Blank spreadsheet)
3. Click "Untitled spreadsheet" at top left → rename to: DASTAWAIZ CRM
4. Press Enter

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 2 — CREATE 5 TABS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
At the bottom, you see "Sheet1" — right-click it → Rename → type: LEADS
Click the + button 4 times to add 4 more sheets. Rename them:
- MATTER ID TRACKER
- EMAIL TEMPLATES
- PRICING
- REFERENCE

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 3 — LEADS TAB HEADERS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Click the LEADS tab.
Click cell A1.
Type each header below, pressing Tab to move to the next cell:

A1: Matter ID
B1: Date Received
C1: Client Name
D1: WhatsApp
E1: Email
F1: Service Type
G1: Document Type
H1: Jurisdiction
I1: Urgency
J1: Lead Source
K1: Status
L1: Notes
M1: Quote (PKR)
N1: Quote Sent
O1: Payment Status
P1: Payment Ref
Q1: Payment Date
R1: Drive Folder Link
S1: AI Draft
T1: Human Review
U1: QC Done
V1: Delivery Date
W1: Follow-Up
X1: Cross-Sell
Y1: Referred To
Z1: Repeat Client

Now select Row 1 (click the "1" on the far left).
Press Ctrl+B (bold).
Go to View → Freeze → 1 row.
Fill row 1 with dark navy color: Format → Text & Fills → Background color → pick dark navy.
Change text color to white.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 4 — STATUS DROPDOWN (Column K)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Click K2. Hold Shift, click K1000.
Go to Data → Data validation → Add rule.
Criteria: Dropdown (from a list)
Enter these items (one per line):
New Lead
Under Review
Info Needed
Quote Sent
Awaiting Payment
Paid
In Progress
Human Review
QC
Ready to Deliver
Delivered
Completed
Follow-Up Done
Closed
Referred — BTaxFiler
Referred — Mr. Laws
Declined
Click Done.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 5 — URGENCY DROPDOWN (Column I)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Same method → Column I → dropdown items:
Standard (5–7 days)
Urgent (2–3 days)
Same Day

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 6 — PAYMENT STATUS DROPDOWN (Column O)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Same method → Column O:
Not Invoiced
Quote Sent
Awaiting Payment
Received — Unverified
Verified — Paid

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 7 — MATTER ID TRACKER TAB
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Click MATTER ID TRACKER tab.
A1: Field | B1: Value
A2: Last Matter Number | B2: 0
A3: Current Year | B3: 2026
A4: Next ID Preview | B4: =CONCATENATE("DA-",B3,"-",TEXT(B2+1,"0000"))

Each time you take a new matter, increase B2 by 1.
The Matter ID to use always shows in B4.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 8 — PRICING TAB
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Click PRICING tab. Paste this table:

Document Type | Standard (PKR) | Urgent (+50%)
NDA / Confidentiality Agreement | 2,500 | 3,750
Freelancer Agreement | 3,500 | 5,250
Employment Agreement | 4,000 | 6,000
Consultancy Agreement | 4,000 | 6,000
Lease / Rent Agreement | 3,500 | 5,250
Software Development Agreement | 7,500 | 11,250
Partnership Agreement | 10,000 | 15,000
Shareholders Agreement | 12,000 | 18,000
Contract Review — Standard | 4,000 | 6,000
Contract Review — Complex | 8,000+ | Quote
Legal Question (written) | 2,500 | —
Freelancer Pack (NDA + Freelancer Agr) | 5,500 | —
Startup Pack (NDA + Partnership + Employment) | 14,000 | —
IT Business Pack (5 documents) | 22,000 | —

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 9 — INSTALL APPS SCRIPT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. In the CRM sheet: click Extensions → Apps Script
2. Delete everything in the editor
3. Open the file 01_apps_script.js from this kit
4. Copy everything → paste into editor
5. Click Save (disk icon, or Ctrl+S)
6. Click Run → select "onOpen" → click Run
7. Google will ask for permissions → click Review permissions → Allow
8. Go back to your sheet — you should see "⚖️ DASTAWAIZ" in the menu bar

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 10 — SET UP FORM TRIGGER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
(Do this AFTER creating your Google Forms and linking them to this sheet)
1. In Apps Script editor → click clock icon (Triggers) on left
2. Click "+ Add Trigger" (bottom right)
3. Function: onFormSubmit
4. Event source: From spreadsheet
5. Event type: On form submit
6. Save
7. Authorize again if asked

-e 


# ═══════ 03_google_forms.md ═══════
# DASTAWAIZ — 3 Google Forms (Exact Build Instructions)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FORM 1 — CREATE MY CONTRACT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Go to forms.google.com → Blank form

TITLE: Create My Contract — DASTAWAIZ
DESCRIPTION:
Tell us about the document you need. Prepared and reviewed by Ahsan Awan, Advocate High Court. We will send you a quotation within 24 hours.

─── SECTION 1: YOUR DETAILS ───

Q1 — Full Name
Type: Short answer | Required: Yes

Q2 — WhatsApp Number
Type: Short answer | Required: Yes
Description: Include country code e.g. +92 300 1234567

Q3 — Email Address
Type: Short answer | Required: Yes

Q4 — Are you an individual or a business?
Type: Multiple choice | Required: Yes
Options:
• Individual / Freelancer
• Registered Business / Company
• Startup
• Other

─── SECTION 2: DOCUMENT DETAILS ───
(Click "Add section" to create a new section)

Q5 — What type of document do you need?
Type: Dropdown | Required: Yes
Options:
NDA / Confidentiality Agreement
Freelancer / Service Agreement
Employment Agreement
Consultancy Agreement
Software Development Agreement
Partnership Agreement
Lease / Rent Agreement
Shareholders Agreement
Vendor / Supplier Agreement
Terms & Conditions
Privacy Policy
MOU (Memorandum of Understanding)
Independent Contractor Agreement
Commission Agreement
Agency Agreement
IP / Intellectual Property Agreement
E-commerce Agreement
Loan Agreement
Settlement Agreement
Other / Custom

Q6 — Who are the parties involved?
Type: Paragraph | Required: Yes
Description: e.g. "I am a freelance developer based in Lahore. My client is a company in the UK. I need to protect my payment and my work."

Q7 — What is the main purpose of this document?
Type: Paragraph | Required: Yes
Description: e.g. "To define payment terms, deliverables and IP ownership for a 3-month web development project."

Q8 — Jurisdiction / Country
Type: Short answer | Required: Yes
Description: Which country's law should apply? e.g. Pakistan, UAE, UK

Q9 — Any specific clauses or requirements?
Type: Paragraph | Required: No
Description: Optional. Leave blank if unsure — we will ask if needed.

─── SECTION 3: TIMING ───

Q10 — How urgently do you need this?
Type: Multiple choice | Required: Yes
Options:
• Standard — 5 to 7 working days
• Urgent — 2 to 3 working days (additional fee applies)
• Same Day (subject to availability — contact us first)

Q11 — How did you find DASTAWAIZ?
Type: Dropdown | Required: Yes
Options:
Google Search
Instagram
LinkedIn
Facebook
TikTok
YouTube
WhatsApp
BTaxFiler
Mr. Laws
Referred by someone
Blog / Article
Other

─── SETTINGS ───
Click Settings (gear icon):
→ Responses: ✅ Collect email addresses
→ Responses: ✅ Send responders a copy of their response
→ Presentation: Set confirmation message to:

"Thank you for contacting DASTAWAIZ.

Your request has been received. A reference number will be assigned and sent to your email within a few minutes.

We will review your submission and send a quotation within 24 hours.

For urgent matters: WhatsApp +92 345 9477707

DASTAWAIZ — Legal Documents. Made Simple."

─── LINK TO SHEET ───
Click Responses tab → green Sheets icon
→ Select existing spreadsheet → DASTAWAIZ CRM
→ Create new sheet tab (it will auto-name it)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FORM 2 — REVIEW MY CONTRACT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Go to forms.google.com → Blank form

TITLE: Review My Contract — DASTAWAIZ
DESCRIPTION:
Upload your agreement for professional review by Ahsan Awan, Advocate High Court. We identify risks, missing clauses and provide written recommendations.

─── SECTION 1: YOUR DETAILS ───

Q1 — Full Name | Short answer | Required
Q2 — WhatsApp Number | Short answer | Required
Q3 — Email Address | Short answer | Required

─── SECTION 2: DOCUMENT DETAILS ───

Q4 — What type of document are you uploading?
Type: Dropdown | Required: Yes
(Same options as Form 1 Q5)

Q5 — What is your position in this agreement?
Type: Multiple choice | Required: Yes
Options:
• Party A
• Party B
• Employer
• Employee
• Client
• Service Provider
• Buyer
• Seller
• Landlord
• Tenant
• Consultant
• Other

Q6 — What is your main concern about this document?
Type: Paragraph | Required: Yes
Description: e.g. "I want to know if this agreement protects me if the client refuses to pay. The termination clause also seems one-sided."

Q7 — Jurisdiction / Country
Type: Short answer | Required: Yes
Description: Which country's law governs this document?

Q8 — Upload your document
Type: File upload | Required: Yes
Settings:
→ Allow only specific file types: ✅ PDF ✅ Word (doc, docx)
→ Maximum number of files: 1
→ Maximum file size: 10 MB

IMPORTANT: When you add a File Upload question, Google will show a popup saying it needs to connect to Google Drive. Click Continue.

Q9 — I confirm I am authorized to share this document
Type: Checkboxes | Required: Yes
Option: ✅ Yes, I confirm I am authorized to upload this document for review

─── SECTION 3: TIMING ───

Q10 — How urgently do you need this review?
Type: Multiple choice | Required: Yes
Options:
• Standard — 5 to 7 working days
• Urgent — 2 to 3 working days (additional fee applies)
• Same Day (subject to availability)

Q11 — How did you find DASTAWAIZ?
Type: Dropdown | Required: Yes
(Same options as Form 1 Q11)

─── SECTION 4: CONSENT ───

Q12 — Terms acceptance
Type: Checkboxes | Required: Yes
Option: ✅ I understand this review is a professional document service. It does not constitute legal advice and does not create an advocate-client relationship unless formally accepted. I accept the DASTAWAIZ Terms of Service.

─── SETTINGS ───
Same as Form 1.
Confirmation message:
"Thank you for uploading your document.

Your request has been received. A reference number will be assigned and sent to your email.

We will send you a quotation within 24 hours.

Your document is handled with strict confidentiality by Ahsan Awan, Advocate High Court.

DASTAWAIZ — +92 345 9477707"

Link to DASTAWAIZ CRM sheet (same sheet, new tab).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FORM 3 — ASK A LEGAL QUESTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TITLE: Ask a Legal Question — DASTAWAIZ
DESCRIPTION:
Have a question about a contract, your rights or your obligations? Submit your question and receive a clear written response from Ahsan Awan, Advocate High Court.

─── SECTION 1: YOUR DETAILS ───

Q1 — Full Name | Short answer | Required
Q2 — WhatsApp Number | Short answer | Required
Q3 — Email Address | Short answer | Required

─── SECTION 2: YOUR QUESTION ───

Q4 — What is your question about?
Type: Dropdown | Required: Yes
Options:
Is this agreement safe for me?
What risks do I carry under this contract?
What clauses are missing?
Can I terminate this agreement?
What happens if the other party breaches?
How can I protect my business?
What should I negotiate before signing?
Is this clause enforceable in Pakistan?
Who owns the intellectual property?
What are my payment rights?
Other / General contract question

Q5 — What type of document is involved?
Type: Dropdown | Required: Yes
(Same document types as before)

Q6 — Which country / jurisdiction does this involve?
Type: Short answer | Required: Yes

Q7 — Describe your situation in detail
Type: Paragraph | Required: Yes
Description: The more detail you provide, the more useful and accurate our response will be.

Q8 — Upload document (optional)
Type: File upload | Required: No
Settings: PDF / Word | 1 file | 10 MB max

Q9 — I confirm I am authorized to share any uploaded document
Type: Checkboxes | Required: No
Option: Yes, I confirm

Q10 — How did you find DASTAWAIZ?
Type: Dropdown | Required: Yes
(Same as before)

─── SETTINGS ───
Confirmation message:
"Thank you for your question.

A reference number will be assigned and sent to your email shortly.

Ahsan Awan, Advocate High Court, will review your query and respond with a written answer within 24 hours.

Note: Written responses provide professional guidance based on the information you have shared. For matters requiring formal legal representation, we will advise you accordingly.

DASTAWAIZ — +92 345 9477707"

Link to DASTAWAIZ CRM sheet (same sheet, new tab).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AFTER CREATING ALL 3 FORMS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Get the shareable link for each form:
   Form 1: Click Send → Link icon → Copy link
   Save these 3 links — you will share them everywhere.

2. Go to your DASTAWAIZ CRM sheet.
   You will now see 3 extra tabs auto-created by the forms.
   Rename them clearly:
   - "Form1 Responses — Create"
   - "Form2 Responses — Review"
   - "Form3 Responses — Question"

3. Your LEADS tab is the master tracking sheet.
   The Apps Script pulls data from form submissions into LEADS automatically.

-e 


# ═══════ 04_page_content.md ═══════
# DASTAWAIZ — Complete Website & Social Content
# Written for: Ahsan Awan, Advocate High Court
# Brand: Lawyer-run legal document platform

═══════════════════════════════════════════════════
PAGE 1 — HOMEPAGE
═══════════════════════════════════════════════════

META TITLE: DASTAWAIZ — Legal Documents by an Advocate High Court | Pakistan
META DESCRIPTION: Create, review and protect your contracts with DASTAWAIZ. Professional legal documents prepared and reviewed by Ahsan Awan, Advocate High Court. Serving Pakistan.

─── HERO ───

HEADLINE:
Legal Documents.
Made Simple.
Done Right.

SUBHEADLINE:
Professional contracts and legal document services — prepared and reviewed by Ahsan Awan, Advocate High Court, Corporate Attorney and Litigator.

[Create My Contract]   [Review My Agreement]   [Ask a Legal Question]

Trust line:
✓ Advocate High Court  ✓ Human-reviewed  ✓ Confidential  ✓ Delivered digitally  ✓ Pakistan

─── CREDIBILITY BANNER ───

Prepared & Reviewed by:
AHSAN AWAN
Advocate High Court | Corporate Attorney | Litigator
Over [X] Years of Legal Experience | Lahore, Pakistan

(This single line eliminates every trust objection a visitor has.)

─── HOW IT WORKS ───

Step 1 — Tell Us What You Need
Submit a simple form in 3 minutes. Tell us the document type, parties and purpose.

Step 2 — We Review and Quote
We review your submission within 24 hours and send a transparent, fixed-price quotation.

Step 3 — Your Document Is Prepared
Ahsan Awan personally reviews every document before delivery. No junior staff. No AI-only output.

Step 4 — Delivered to Your Inbox
Receive your professionally prepared document as PDF and editable DOCX. Fully remote. No office visit required.

─── THREE SERVICE CARDS ───

📄 Create a Contract
Need a professionally drafted agreement? We create NDAs, employment contracts, freelancer agreements, software development contracts, partnership deeds and more — tailored to your exact situation and reviewed by an Advocate High Court.
[Create My Contract →]

🔍 Review My Agreement
Received a contract you are unsure about? Upload it and Ahsan Awan will identify every risk, unfair clause and missing protection — before you sign.
[Review My Agreement →]

💬 Ask a Legal Question
Have a question about a contract clause, your rights or what a term means? Submit your question and receive a clear, written response.
[Ask a Legal Question →]

─── WHY DASTAWAIZ ───

⚖️ Prepared by an Advocate High Court
Every document is personally reviewed by Ahsan Awan — a qualified Advocate High Court, corporate attorney and litigator with real legal practice experience.

💰 Affordable Professional Quality
Significantly more affordable than traditional law firm rates — without compromising on quality or accuracy.

⚡ Fast Turnaround
Standard: 5–7 working days. Urgent: 2–3 days. Same-day available.

🔒 Strictly Confidential
Every document is handled with full professional confidentiality. Secure storage. Restricted access.

📱 Fully Remote
No office visit needed. Submit online, receive your document digitally. Serving all of Pakistan and overseas Pakistanis.

🇵🇰 Pakistan-Focused
We understand Pakistani business practices, commercial culture and legal requirements.

─── WHO WE SERVE ───

For Freelancers & Consultants — Protect your work and your payment
For IT Companies & Software Houses — Secure your projects and your IP
For Startups — Build your business on solid legal foundations
For Employers — Employment agreements that protect your business
For SMEs — Professional contracts for every business relationship
For Landlords & Tenants — Lease agreements that hold up
For E-commerce Businesses — Terms, policies and supplier agreements
For Overseas Pakistanis — Remote service, Pakistani law expertise

─── POPULAR DOCUMENTS ───

NDA / Confidentiality Agreement — from PKR 2,500
Freelancer Agreement — from PKR 3,500
Employment Agreement — from PKR 4,000
Software Development Agreement — from PKR 7,500
Lease / Rent Agreement — from PKR 3,500
Partnership Agreement — from PKR 10,000

[View All Documents & Pricing →]

─── FOOTER CTA ───

Ready to protect your business?
[Create My Contract]   [Review My Agreement]

DASTAWAIZ
Legal Documents. Made Simple. Done Right.
Prepared by Ahsan Awan, Advocate High Court

WhatsApp: +92 345 9477707
Email: dastawaizpk@gmail.com

═══════════════════════════════════════════════════
PAGE 2 — ABOUT DASTAWAIZ
═══════════════════════════════════════════════════

META TITLE: About DASTAWAIZ — Advocate High Court Legal Document Service Pakistan
META DESCRIPTION: DASTAWAIZ is a lawyer-run legal document platform. Ahsan Awan, Advocate High Court, personally prepares and reviews every document. Learn more.

HEADLINE: About DASTAWAIZ

DASTAWAIZ was founded on a simple observation: most individuals, freelancers and small businesses in Pakistan execute contracts on trust, use borrowed templates or sign documents they do not fully understand.

The consequences can be severe — missed payments, IP disputes, one-sided terminations and costly litigation that could have been prevented with a properly drafted agreement.

DASTAWAIZ exists to change that.

─── WHO IS BEHIND DASTAWAIZ ───

DASTAWAIZ is founded and led by Ahsan Awan, an Advocate High Court, corporate attorney and litigator with extensive experience in commercial law, corporate transactions, employment law and contractual disputes.

Unlike generic document platforms, DASTAWAIZ is not an algorithm. Every document request is personally reviewed. Every contract is professionally examined before delivery. You are not receiving a template — you are receiving professional legal document work.

─── OUR APPROACH ───

We combine legal expertise with technology to make professional document services accessible and affordable.

We use AI tools internally to assist with research and drafting. But every document is reviewed and approved by Ahsan Awan before it reaches you. AI accelerates our work. It does not replace professional judgment.

─── OUR SERVICES ───

Contract Creation — Professionally drafted agreements tailored to your specific situation
Contract Review — Expert analysis of agreements before you sign
Legal Questions — Written responses to your contractual questions

─── PART OF A CONNECTED ECOSYSTEM ───

DASTAWAIZ is part of a connected group of professional services:

⚖️ DASTAWAIZ — Legal documents and contracts
🏢 BTaxFiler — Tax, corporate and compliance solutions
📋 Mr. Laws — Broader legal consultancy and representation

Where a client's matter requires services beyond legal document preparation — such as company incorporation, tax registration or formal legal representation — DASTAWAIZ coordinates the appropriate professional introduction.

═══════════════════════════════════════════════════
PAGE 3 — CONTRACT CREATION
═══════════════════════════════════════════════════

META TITLE: Contract Drafting Service Pakistan — Advocate High Court | DASTAWAIZ
META DESCRIPTION: Get professionally drafted contracts reviewed by an Advocate High Court. NDA, employment, freelancer, software agreements and more. Pakistan. Affordable.

HEADLINE: Create Your Contract

Your contract is not just a form — it is a legally binding commitment. Get it right from the start.

Every DASTAWAIZ contract is:
→ Drafted based on your specific situation
→ Reviewed by Ahsan Awan, Advocate High Court
→ Delivered as PDF and editable DOCX
→ Governed by the correct jurisdiction

[Create My Contract — Start Now →]

─── AVAILABLE DOCUMENTS ───

FOR FREELANCERS & CONSULTANTS
• Freelancer / Service Agreement — from PKR 3,500
• Consultancy Agreement — from PKR 4,000
• NDA / Confidentiality Agreement — from PKR 2,500
• Independent Contractor Agreement — from PKR 4,000

FOR BUSINESSES & EMPLOYERS
• Employment Agreement — from PKR 4,000
• Vendor / Supplier Agreement — from PKR 5,000
• Service Agreement — from PKR 4,000
• Agency Agreement — from PKR 5,500
• Commission Agreement — from PKR 4,500

FOR STARTUPS
• Partnership Agreement — from PKR 10,000
• Shareholders Agreement — from PKR 12,000
• IP Assignment Agreement — from PKR 6,000
• Co-Founder Agreement — from PKR 8,000

FOR IT & SOFTWARE COMPANIES
• Software Development Agreement — from PKR 7,500
• Software Licensing Agreement — from PKR 7,000
• IT Service / Maintenance Agreement — from PKR 6,000
• Data Processing Agreement — from PKR 6,500

FOR PROPERTY
• Residential Lease Agreement — from PKR 3,500
• Commercial Lease Agreement — from PKR 5,000
• Rent Agreement — from PKR 3,000

FOR E-COMMERCE & ONLINE BUSINESS
• Website Terms & Conditions — from PKR 5,000
• Privacy Policy — from PKR 4,000
• E-commerce Supplier Agreement — from PKR 5,500

OTHER
• MOU (Memorandum of Understanding) — from PKR 6,000
• Loan Agreement — from PKR 5,000
• Settlement Agreement — from PKR 7,000
• General Legal Notice — from PKR 3,000
• Custom / Any other document — Request Quote

═══════════════════════════════════════════════════
PAGE 4 — CONTRACT REVIEW
═══════════════════════════════════════════════════

META TITLE: Contract Review Service Pakistan — Advocate High Court | DASTAWAIZ
META DESCRIPTION: Have your contract reviewed by Ahsan Awan, Advocate High Court. Identify risks and missing clauses before you sign. Pakistan contract review service.

HEADLINE: Review My Agreement

Before you sign anything, know exactly what you are agreeing to.

Ahsan Awan, Advocate High Court, reviews your agreement in detail and provides a clear written report identifying every risk, unfair clause and missing protection.

[Upload My Document →]

─── WHAT THE REVIEW COVERS ───

✓ Are the parties correctly identified?
✓ Are payment terms clear, fair and protected?
✓ Are termination rights balanced?
✓ What liability do you carry?
✓ Is there an indemnity clause working against you?
✓ Is confidentiality adequately protected?
✓ Who owns intellectual property — including work you create?
✓ What is the governing law and dispute mechanism?
✓ Are there non-compete or restriction clauses?
✓ What happens if the other party breaches?
✓ What clauses are missing that should protect you?
✓ What should you negotiate before signing?

─── WHAT YOU RECEIVE ───

A clear written review with:
→ Plain English summary of what the agreement actually says
→ Risk flags — identified and explained
→ Missing clause recommendations
→ Suggested negotiation points
→ Overall risk assessment: Low / Medium / High

─── WHEN YOU NEED THIS ───

→ Before signing any significant business contract
→ When a large company sends you their standard terms
→ When you are an employee receiving an employment offer
→ Before entering a partnership or joint venture
→ Before signing a commercial lease
→ Any time you feel uncertain about what you are signing

Contract Review — from PKR 4,000
[Upload My Document →]

═══════════════════════════════════════════════════
PAGE 5 — PRICING
═══════════════════════════════════════════════════

META TITLE: Legal Document Prices Pakistan — DASTAWAIZ | Transparent & Affordable
META DESCRIPTION: Transparent, affordable pricing for contract drafting and review in Pakistan. Reviewed by Advocate High Court. Fixed prices. No hidden fees.

HEADLINE: Simple, Transparent Pricing

Professional legal document services at a fraction of traditional law firm rates.
Reviewed by Ahsan Awan, Advocate High Court. No hidden fees.

─── CONTRACT CREATION ───

Document | Starting Price (PKR)
NDA / Confidentiality Agreement | 2,500
Freelancer / Service Agreement | 3,500
Employment Agreement | 4,000
Consultancy Agreement | 4,000
Lease / Rent Agreement | 3,500
Software Development Agreement | 7,500
Partnership Agreement | 10,000
Shareholders Agreement | 12,000
Other / Custom | Request Quote

Urgent Service (2–3 working days): +50% on standard price

─── CONTRACT REVIEW ───

Standard Contract Review | from PKR 4,000
Complex Agreement Review | from PKR 8,000
Same-Day Review | Contact us

─── LEGAL QUESTION (WRITTEN RESPONSE) ───

Per matter | from PKR 2,500

─── PACKAGES ───

Freelancer Starter Pack
NDA + Freelancer Agreement
PKR 5,500 (save PKR 500)
[Get This Package →]

Startup Legal Pack
NDA + Partnership Agreement + Employment Agreement
PKR 14,000 (save PKR 2,000)
[Get This Package →]

IT Business Pack
NDA + Software Dev Agreement + Service Agreement + Employment Agreement + Privacy Policy
PKR 22,000 (save PKR 3,500)
[Get This Package →]

─── PAYMENT METHODS ───
Bank Transfer | Easypaisa | JazzCash | Raast

─── NOT SURE? ───
[Request a Custom Quote →]   [Ask a Legal Question →]

All prices include one reasonable revision within 7 days of delivery.

═══════════════════════════════════════════════════
PAGE 6 — FAQ
═══════════════════════════════════════════════════

META TITLE: FAQ — DASTAWAIZ Legal Document Service Pakistan
META DESCRIPTION: Common questions about DASTAWAIZ contract drafting and review services, turnaround, pricing and document delivery.

Q: Who reviews my documents at DASTAWAIZ?
A: Every paid document or review is personally examined by Ahsan Awan, Advocate High Court, Corporate Attorney and Litigator. DASTAWAIZ is not a generic template platform — it is a lawyer-run professional service.

Q: Is DASTAWAIZ a law firm?
A: DASTAWAIZ is a professional legal document preparation and review service run by a qualified Advocate High Court. For matters requiring court representation, formal litigation or regulated legal practice, we will advise you accordingly and refer you to the appropriate service.

Q: Do you use AI to prepare documents?
A: We use AI tools internally to assist with research, analysis and drafting. Every document is then reviewed and approved by Ahsan Awan before delivery. AI accelerates professional work — it does not replace legal judgment at DASTAWAIZ.

Q: How long does it take?
A: Standard turnaround is 5–7 working days. Urgent service (2–3 days) is available at an additional fee. Same-day service is available subject to availability — contact us first.

Q: Is my document confidential?
A: Absolutely. All documents and information you share are handled with full professional confidentiality. We do not share your documents with any third party. Secure, restricted storage is used throughout.

Q: What file formats do you accept for review?
A: PDF, DOC and DOCX. Maximum file size: 10 MB.

Q: What do I receive after my contract is drafted?
A: A professionally formatted PDF and an editable DOCX version. One reasonable revision is included within 7 days of delivery.

Q: Which jurisdictions do you cover?
A: Primarily Pakistani law. We also prepare documents under UAE, UK and general international commercial law. Always specify your jurisdiction when submitting.

Q: How do I pay?
A: Bank transfer, Easypaisa, JazzCash or Raast. Payment instructions are included in your quotation.

Q: What if I need a document not listed on your website?
A: Submit a custom request. We will advise whether we can assist and provide a quotation.

Q: Can DASTAWAIZ help with a dispute or going to court?
A: DASTAWAIZ focuses on document preparation and review. For active disputes or litigation, we refer clients to our associated legal practice, Mr. Laws.

Q: Do you serve clients outside Pakistan?
A: Yes. Overseas Pakistanis and foreign businesses requiring Pakistani-law documents are welcome. We are fully remote.

═══════════════════════════════════════════════════
PAGE 7 — LEGAL DISCLAIMER
═══════════════════════════════════════════════════

META TITLE: Legal Disclaimer — DASTAWAIZ

LEGAL DISCLAIMER

1. Professional Document Service
DASTAWAIZ is a professional legal document preparation and review service operated by Ahsan Awan, Advocate High Court. It is not a law firm. Use of this website or our services does not automatically create an advocate-client relationship. A formal engagement must be accepted before any advocate-client relationship is established.

2. Not Legal Advice
Content on this website — including blog posts, articles, general information and AI-assisted responses — is provided for general informational purposes only. It does not constitute legal advice and should not be relied upon as such for any specific legal matter.

3. Professional Review
Paid document services are reviewed by Ahsan Awan before delivery. However, every legal situation is unique. For significant commercial transactions, employment matters, property dealings or matters involving substantial rights, independent legal advice from a qualified advocate is always recommended.

4. AI Disclosure
DASTAWAIZ uses artificial intelligence tools internally to assist with document analysis, research and drafting. All AI-assisted work is reviewed and approved by Ahsan Awan before reaching any client. AI is a tool — not a substitute for professional legal judgment.

5. No Guaranteed Outcomes
DASTAWAIZ makes no representation regarding the legal validity, enforceability or commercial suitability of any document in any specific transaction. Legal outcomes depend on many factors outside our control.

6. Limitation of Liability
DASTAWAIZ's liability in respect of any service is limited to the fee paid for that specific service.

7. Jurisdiction
Services are primarily designed for documents governed by Pakistani law. Limitations for foreign-law documents will be advised upon submission.

═══════════════════════════════════════════════════
PAGE 8 — AI DISCLAIMER
═══════════════════════════════════════════════════

META TITLE: AI Disclaimer — DASTAWAIZ

AI DISCLAIMER

DASTAWAIZ uses artificial intelligence technology as an internal tool.

What AI does at DASTAWAIZ:
→ Assists with analysing and summarising submitted documents
→ Helps identify clause structures and document types
→ Supports initial drafting frameworks
→ Helps identify potentially missing or unusual provisions

What AI does NOT do at DASTAWAIZ:
→ AI does not communicate directly with clients on paid matters
→ AI does not provide final legal conclusions without human review
→ AI does not replace the professional judgment of Ahsan Awan
→ AI is not a licensed advocate and does not practice law
→ AI output is always reviewed before delivery

Your Consent:
By submitting a request to DASTAWAIZ, you consent to your submission being processed using AI tools as part of our internal preparation process, subject to our Privacy Policy and in accordance with this disclosure.

═══════════════════════════════════════════════════
GOOGLE BUSINESS PROFILE DESCRIPTION
═══════════════════════════════════════════════════

DASTAWAIZ is a professional legal document service founded by Ahsan Awan, Advocate High Court, Corporate Attorney and Litigator, based in Lahore, Pakistan.

We create and review contracts, agreements and legal documents for businesses, freelancers, startups and individuals — at a fraction of traditional law firm rates.

Services: NDA drafting, employment agreements, freelancer contracts, software development agreements, partnership deeds, shareholders agreements, lease agreements, contract review and written legal guidance.

Every document is personally reviewed by an Advocate High Court. Fully remote. Serving all of Pakistan and overseas Pakistanis.

Contact: +92 345 9477707 | dastawaizpk@gmail.com

═══════════════════════════════════════════════════
INSTAGRAM BIO
═══════════════════════════════════════════════════

⚖️ Legal Documents. Made Simple.
By Ahsan Awan, Advocate High Court
📄 Create | Review | Protect
🇵🇰 Pakistan | Fully Remote
👇 Get Your Contract

[Link: Google Form — Create My Contract]

═══════════════════════════════════════════════════
LINKEDIN PAGE DESCRIPTION
═══════════════════════════════════════════════════

DASTAWAIZ is Pakistan's professional legal document platform — founded and led by Ahsan Awan, Advocate High Court, Corporate Attorney and Litigator.

We make professional legal documents accessible and affordable for businesses, freelancers, startups and individuals across Pakistan.

Our services include contract drafting, agreement review and written legal guidance — with every document personally reviewed by a qualified Advocate High Court.

DASTAWAIZ is part of a connected professional ecosystem alongside BTaxFiler (tax and corporate solutions) and Mr. Laws (legal consultancy and representation).

Fully remote. Serving Pakistan and overseas Pakistanis.

-e 


# ═══════ 05_claude_prompts.md ═══════
# DASTAWAIZ — Internal Claude Prompts
# Use these in Claude Pro. Never send AI output to client without reviewing first.
# Ahsan Awan, Advocate High Court — you review everything before delivery.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROMPT 1 — CONTRACT DRAFTING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

You are assisting Ahsan Awan, Advocate High Court and Corporate Attorney, in drafting a legal document for a client of DASTAWAIZ, a professional legal document service based in Pakistan.

CLIENT DETAILS:
- Client name / description: [FILL]
- Client type: [Individual / Business / Startup]
- Document type: [FILL e.g. Software Development Agreement]
- Party A: [Name + Role e.g. "Ali Ahmed, Software Developer"]
- Party B: [Name + Role e.g. "XYZ Pvt Ltd, Client Company"]
- Purpose of document: [FILL]
- Key commercial terms: [FILL — payment, duration, deliverables, milestones etc.]
- Governing jurisdiction: [Pakistan / UAE / UK / Other]
- Special requirements: [FILL or write "None"]
- Urgency: [Standard / Urgent]

TASK:
Draft a complete, professionally structured [DOCUMENT TYPE] based on the above.

Requirements:
1. Apply [JURISDICTION] law as the governing law
2. Use clear, professional English
3. Number all clauses
4. Include all standard sections: Definitions, Obligations of Each Party, Payment Terms, Term & Duration, Termination, Confidentiality, Intellectual Property (if relevant), Liability & Indemnity, Representations & Warranties, Governing Law, Dispute Resolution, General/Boilerplate (force majeure, entire agreement, amendments, notices, severability, waiver)
5. After the draft: list any items flagged for Ahsan's attention or requiring client clarification
6. Do not insert legal disclaimers inside the body of the contract

Draft the complete document now.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROMPT 2 — CONTRACT REVIEW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

You are assisting Ahsan Awan, Advocate High Court, in reviewing a legal document for a DASTAWAIZ client. Your analysis is a preliminary review for Ahsan's professional examination — not a final legal opinion.

CLIENT CONTEXT:
- Client position: [Party A / Party B / Employer / Employee / etc.]
- Client's main concern: [FILL]
- Jurisdiction: [FILL]
- Document type: [FILL]

DOCUMENT:
[PASTE FULL DOCUMENT TEXT]

REVIEW — analyse from the perspective of [CLIENT POSITION]:

1. SUMMARY — What does this agreement do in plain English?
2. KEY OBLIGATIONS — What must the client do?
3. KEY RIGHTS — What rights does the client have?
4. PAYMENT TERMS — Are they clear, fair and protected?
5. TERMINATION — How can the agreement end? Is it balanced?
6. LIABILITY & INDEMNITY — What exposure does the client carry?
7. CONFIDENTIALITY — Adequately protected?
8. INTELLECTUAL PROPERTY — Who owns what? Is it appropriate?
9. GOVERNING LAW & DISPUTES — Which law and forum?
10. MISSING CLAUSES — What standard protections are absent?
11. ONE-SIDED CLAUSES — What is unfairly weighted against the client?
12. UNUSUAL / HIGH-RISK CLAUSES — Flag anything abnormal
13. NEGOTIATION POINTS — Top 3–5 things to negotiate before signing
14. RISK RATING — Low / Medium / High with brief explanation

Write clearly. Use numbered headings. Plain English throughout.
This is a preliminary analysis for Ahsan Awan's review before client delivery.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROMPT 3 — LEGAL QUESTION RESPONSE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

You are assisting Ahsan Awan, Advocate High Court, in drafting a written response to a client's legal question for DASTAWAIZ. Ahsan will review and edit this before sending.

CLIENT QUESTION:
- Question type: [FILL]
- Document type involved: [FILL]
- Jurisdiction: [FILL]
- Client situation: [FILL in detail]
- Relevant document clauses: [PASTE if available]

TASK:
Draft a professional written response that:
1. Directly addresses the specific question
2. Explains the relevant legal position in plain English
3. Identifies risks or issues the client should know
4. Where appropriate, suggests practical steps
5. Where the matter exceeds document services (e.g. court proceedings), states this clearly
6. Does NOT guarantee any legal outcome
7. Does NOT claim to be practicing law — frames as professional guidance
8. Is concise and practical — not padded

Ahsan Awan will review, edit and send this response.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROMPT 4 — QUALITY CONTROL CHECK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Perform a quality control check on this DASTAWAIZ document before delivery.

Matter ID: [DA-2026-XXXX]
Document type: [FILL]
Client: [FILL]
Jurisdiction: [FILL]

DOCUMENT:
[PASTE FULL DOCUMENT]

CHECK AND REPORT ON EACH:

1. PARTY NAMES — Consistent throughout?
2. DEFINED TERMS — Used consistently? Any undefined terms?
3. DATES — All correct and internally consistent?
4. CLAUSE REFERENCES — All internal references accurate?
5. PAYMENT TERMS — Amount, date, method clearly stated?
6. TERMINATION — Clause present and clearly worded?
7. GOVERNING LAW — Clause present and correct?
8. DISPUTE RESOLUTION — Clause present and appropriate?
9. SIGNATURE BLOCKS — Correctly formatted for all parties?
10. FORMATTING — Consistent throughout? Professional appearance?
11. SPELLING — Any errors?
12. MISSING STANDARD CLAUSES — Anything obviously absent?
13. INTERNAL CONTRADICTIONS — Any conflicting provisions?

Report: PASS or ISSUE for each.
List all issues clearly.
Final verdict: READY FOR DELIVERY or REQUIRES AMENDMENT.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROMPT 5 — CLIENT EMAIL GENERATOR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Write a professional email for DASTAWAIZ.

Email type: [Quotation / Info Required / Payment Confirmed / Delivery / Follow-Up]
Matter ID: [DA-2026-XXXX]
Client name: [FILL]
Document type: [FILL]
Key details: [FILL — amount / date / drive link / what info needed]

Requirements:
- Professional but warm tone
- Brief and clear — no padding
- Sign off: Ahsan Awan | Advocate High Court | DASTAWAIZ | +92 345 9477707
- Do not include legal advice in routine emails

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROMPT 6 — DAILY ADMIN (USE EVERY MORNING)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

I run DASTAWAIZ, a legal document service. I am Ahsan Awan, Advocate High Court.

My open matters today:

[PASTE YOUR LEADS SHEET — Matter ID | Client | Document | Status | Date | Notes]

Help me prioritize today:
1. What needs action TODAY?
2. What follow-ups are overdue?
3. Any matters stuck too long in one status?
4. Suggested next action for each open matter

Keep it brief. Practical only.

-e 


# ═══════ 06_blog_posts.md ═══════
# DASTAWAIZ — 5 SEO Blog Posts

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
POST 1
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SLUG: /blog/freelancer-agreement-pakistan
TITLE: Freelancer Agreement Pakistan — What You Must Include (2026)
META: Every Pakistani freelancer needs a proper service agreement. Here's exactly what to include to protect your payment and your work.
KEYWORD: freelancer agreement Pakistan

Every Pakistani freelancer working without a written agreement is gambling with their income.

When a client refuses to pay, changes the scope mid-project or claims your work belongs to them, a WhatsApp conversation protects nothing. A properly drafted freelancer agreement — reviewed by a qualified Advocate High Court — does.

7 THINGS YOUR FREELANCER AGREEMENT MUST INCLUDE:

1. Exact Deliverables
What you will deliver, in what format, by when. Vague scope = endless revisions = unpaid disputes.

2. Payment Terms
Fixed amount, payment schedule (upfront deposit, milestones, final), payment method and what happens if payment is late (interest, work suspension, legal action).

3. Intellectual Property Ownership
By default under Pakistani law, you retain IP unless specifically transferred in writing. Your agreement must be explicit.

4. Revision Policy
How many revisions are included? What constitutes a major change requiring extra payment?

5. Confidentiality
If you access the client's business information, both parties need protection.

6. Termination Rights
Who can end the agreement, under what circumstances, what happens to work completed and payment owed.

7. Governing Law
Pakistan, UAE, UK — whatever applies. Essential for international clients.

Common Pakistani freelancer mistakes:
- Starting work before signing
- Relying on email as a contract
- Delivering everything before receiving full payment
- Using a foreign template unfit for Pakistani law

Get your freelancer agreement drafted and reviewed by Ahsan Awan, Advocate High Court.
Starting PKR 3,500. [Create My Contract →]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
POST 2
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SLUG: /blog/nda-pakistan
TITLE: NDA Pakistan — Complete Guide to Non-Disclosure Agreements (2026)
META: What is an NDA? When do you need one in Pakistan? What must it include? Complete guide for businesses, startups and freelancers.
KEYWORD: NDA Pakistan

Before sharing your business idea, source code, client list or any confidential information — you need an NDA.

WHAT IS AN NDA?
A Non-Disclosure Agreement creates a legal obligation of confidentiality. If the other party shares your information, you have legal remedies. Without one, you have nothing.

WHEN DO YOU NEED ONE?
- Sharing a business idea with a potential co-founder or investor
- Hiring a developer who will access proprietary systems
- Any business discussion involving sensitive information
- When employees or contractors access trade secrets
- Joint venture discussions

TWO TYPES:
Unilateral — only you are disclosing. Used for contractors and investors.
Mutual — both parties share. Used for partnerships and joint ventures.

WHAT IT MUST INCLUDE:
1. Precise definition of what is confidential
2. Obligations of the receiving party
3. Exclusions (public domain, independently developed)
4. Duration — how long must confidentiality last?
5. Consequences of breach
6. Return or destruction of materials
7. Governing law

Can you use a free template? You can — but a generic foreign template may not be enforceable under Pakistani law and may have gaps that leave you completely exposed.

NDA drafted and reviewed by Ahsan Awan, Advocate High Court.
Starting PKR 2,500. [Create My NDA →]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
POST 3
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SLUG: /blog/employment-agreement-pakistan
TITLE: Employment Agreement Pakistan — What Every Employer Must Include (2026)
META: Every employer in Pakistan needs a written employment agreement. What it must include under Pakistani employment law.
KEYWORD: employment agreement Pakistan

Hiring without a written employment agreement is the most common legal mistake Pakistani employers make.

When a dispute arises — wrongful termination claim, salary dispute, IP conflict — the employer without a written contract is in an extremely weak position.

YOUR EMPLOYMENT AGREEMENT MUST COVER:

Job title and description — exactly what the employee will do
Compensation — salary, increments, bonuses, deductions
Working hours — standard, overtime policy
Leave entitlements — under Pakistani labor law (annual, sick, casual)
Probation period — standard terms and termination during probation
Confidentiality — protecting business information
Non-compete — carefully drafted (broad non-competes are often unenforceable)
Termination — notice period, grounds for summary dismissal
EOBI and SESSI — employer obligations under Pakistani law
Governing law — Pakistan

For IT companies and software houses: also include IP ownership clause making clear that all work created during employment belongs to the company.

Employment agreements drafted by Ahsan Awan, Advocate High Court.
Starting PKR 4,000. [Create My Employment Agreement →]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
POST 4
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SLUG: /blog/contract-red-flags-pakistan
TITLE: 7 Red Flags in Any Business Contract You Must Never Ignore
META: Before signing any contract in Pakistan, check for these 7 warning signs that could cost your business dearly.
KEYWORD: contract review Pakistan

Most people sign contracts without reading them properly. These 7 clauses could destroy your business.

1. UNLIMITED LIABILITY
You are responsible for every possible loss the other party suffers — including things beyond your control. Always insist on a liability cap.

2. ONE-SIDED TERMINATION
They can terminate instantly for any reason. You must give 90 days notice. Push for balanced rights.

3. AUTOMATIC RENEWAL
Agreement silently renews for another year unless you cancel in writing 60 days before expiry. Many businesses miss this and are locked in.

4. VAGUE PAYMENT TERMS
"Payment within a reasonable time" is not a payment term. Insist on exact dates, amounts and late payment consequences.

5. BROAD IP ASSIGNMENT
Everything you create — even work unrelated to this contract — belongs to the other party. Read IP clauses with extreme care.

6. FOREIGN JURISDICTION
Any dispute must be resolved in the courts of [foreign country]. You would need to hire foreign lawyers to enforce your rights. Insist on Pakistan.

7. OPEN-ENDED INDEMNITY
You indemnify them against any claim from any third party. You could be paying for their mistakes.

Never sign a contract you haven't had reviewed by a professional.
Contract review by Ahsan Awan, Advocate High Court.
Starting PKR 4,000. [Review My Contract →]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
POST 5
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SLUG: /blog/software-development-agreement-pakistan
TITLE: Software Development Agreement Pakistan — Complete Guide for IT Companies
META: Pakistani IT companies need a proper software development agreement. What it must include to protect both sides. Guide for software houses and clients.
KEYWORD: software development agreement Pakistan

Pakistan's IT sector generates billions in exports. Yet most software projects still run on verbal agreements, WhatsApp messages and trust.

The result: payment disputes, IP conflicts, scope arguments and relationships destroyed.

YOUR SOFTWARE DEVELOPMENT AGREEMENT MUST COVER:

Scope of Work — exact deliverables, tech stack, platforms, acceptance criteria
Payment Milestones — tied to specific deliverables, not just time
IP Ownership — critical. Who owns the final code? What about third-party libraries? What if the client doesn't pay in full — do they still get the IP?
Source Code Escrow — for long-term projects: what happens if the developer disappears?
Bug Fix Warranty — post-delivery support period, what's covered, what's extra
Confidentiality — client's business logic, data and systems
Non-Solicitation — prevents poaching of each other's team members
Termination — who owns what at each stage if the project ends early
Governing Law — Pakistan or as specified

For Pakistani software houses working with international clients: ensure governing law, dispute resolution forum and payment currency are explicitly stated. Do not assume.

Software development agreements drafted by Ahsan Awan, Advocate High Court.
Starting PKR 7,500. [Create My Software Agreement →]

-e 


# ═══════ 07_social_media.md ═══════
# DASTAWAIZ — Social Media Strategy & Content Kit

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PLATFORM SETUP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HANDLE: @dastawaiz (use everywhere — Instagram, LinkedIn, Facebook, TikTok, YouTube, X)
Register this handle NOW on all platforms even if you don't use them yet.

USERNAME PRIORITY:
1. Instagram: @dastawaiz
2. LinkedIn Company: dastawaiz
3. Facebook Page: DASTAWAIZ
4. TikTok: @dastawaiz
5. YouTube: @dastawaiz
6. X/Twitter: @dastawaiz

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BRAND VOICE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Tone: Authoritative but accessible. Never condescending.
Language: English primary. Roman Urdu for wider reach.
Personality: Ahsan is the face. Real lawyer. Real expertise. Real protection.
What we don't do: Corporate jargon, fear-mongering, overselling.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CONTENT PILLARS (5 types, rotate daily)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PILLAR 1 — EDUCATION (trust builder)
"Did you know..." facts about contracts
Common legal mistakes businesses make
What specific clauses actually mean
Real-world consequences of bad contracts

PILLAR 2 — CLIENT PROTECTION (lead generator)
"Before you sign..." warnings
Red flag checklists
"Questions to ask before..." posts
Quick contract health checks

PILLAR 3 — SOCIAL PROOF (credibility)
Client wins (anonymized)
Before/after: bad contract → protected contract
Testimonials
Stats ("We've reviewed X agreements...")

PILLAR 4 — SERVICES (conversion)
Document spotlights with pricing
Package promotions
Urgency posts ("Freelancer season — protect yourself")
Direct CTAs

PILLAR 5 — AUTHORITY (positioning)
Ahsan's expertise and background
Legal news affecting Pakistani businesses
Commentary on common business legal issues
"Ask Ahsan" Q&A format

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
30 READY-TO-POST CAPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

--- EDUCATION ---

1.
Your freelancer contract needs these 7 things:
✅ Exact deliverables
✅ Payment schedule with deposit
✅ Who owns the IP
✅ Revision limit
✅ Confidentiality clause
✅ Termination rights
✅ Governing law (Pakistan / UAE / UK)

Missing even one of these can cost you everything.

Get yours drafted by an Advocate High Court.
Link in bio 👆
#FreelancerPakistan #ContractPakistan #DASTAWAIZ

---

2.
That NDA you downloaded for free from Google?

It may not be enforceable under Pakistani law.
It may define "confidential" so broadly it means nothing.
It may have no remedy clause if the other party leaks.

A proper NDA takes one day to prepare and protects you forever.

DASTAWAIZ — from PKR 2,500
Link in bio 👆
#NDA #Pakistan #LegalDocuments #DASTAWAIZ

---

3.
Signing a contract without reading it properly is one of the most expensive mistakes a business can make.

3 clauses most people miss:
👉 Auto-renewal clause (you're locked in without realising)
👉 Unlimited liability (you pay for everything that goes wrong)
👉 Foreign jurisdiction (you'd have to sue abroad)

Send us your contract. We'll find everything that could hurt you.
Contract review from PKR 4,000.
#ContractReview #Pakistan #DASTAWAIZ

---

4.
IT companies: who owns the code?

If your employment agreement doesn't explicitly say the company owns all work created during employment — your developer could walk out with your product.

This one clause can save your entire business.

Employment agreements from PKR 4,000.
DM or link in bio 👆
#SoftwareHousePakistan #ITCompany #DASTAWAIZ

---

5.
Roman Urdu post:

Agar aap ne abhi tak apne freelance clients ke saath koi written agreement sign nahi kiya —
aap legally completely unprotected hain.

Client payment rok le?
Aap kuch nahi kar sakte bina written contract ke.

DASTAWAIZ — Professional legal documents.
Advocate High Court reviewed.
PKR 3,500 se shuru.

DM karen ya link in bio 👆
#FreelancerPakistan #DASTAWAIZ

---

6.
5 signs your employment contract needs to be reviewed:

1. No probation period defined
2. No IP ownership clause
3. No non-disclosure for business information
4. Notice period only benefits the employer
5. No clear grounds for termination

Protect your business. Get it right before something goes wrong.
#EmployerPakistan #HRPakistan #DASTAWAIZ

---

7.
Partnership agreements: the document everyone skips until things go wrong.

What happens if one partner wants to leave?
What if one partner stops contributing?
How are profits divided?
Who has final decision-making authority?

Sort it out in writing before there's a problem.
Partnership agreements from PKR 10,000.
#StartupPakistan #PartnershipAgreement #DASTAWAIZ

---

8.
Client: "We don't need a contract, we trust each other."

Three months later: "You said the project included X."
"No, I said it didn't."

A 5-page agreement would have prevented a 5-month dispute.

DASTAWAIZ. Legal documents that protect real business relationships.
#BusinessPakistan #SMEPakistan #DASTAWAIZ

---

9.
Software houses: your client's contract protects THEM. Not you.

Standard client contracts typically include:
❌ Unlimited revisions
❌ IP transferred before full payment
❌ You responsible for consequential damages
❌ Governing law in their country

Counter with your own agreement.
Software development agreements from PKR 7,500.
#SoftwareHousePakistan #ITExportPakistan #DASTAWAIZ

---

10.
Roman Urdu:

Contract review karna zaroori kyun hai?

Isliye ke jo agreement aap sign kar rahe hain — wo doosri party ne apne lawyer se likwaya hai.

Unhe ek lawyer mila. Aapko bhi chahiye.

DASTAWAIZ — Advocate High Court se review karwayein.
PKR 4,000 se.
DM karen. 👆
#Pakistan #DASTAWAIZ

---

--- SERVICES ---

11.
📄 NDA — PKR 2,500
📄 Freelancer Agreement — PKR 3,500
📄 Employment Agreement — PKR 4,000
📄 Software Dev Agreement — PKR 7,500
📄 Partnership Agreement — PKR 10,000

Every document reviewed by Ahsan Awan, Advocate High Court.

Link in bio to get started. 👆
#DASTAWAIZ #ContractPakistan #LegalDocuments

---

12.
Startup Pack — PKR 14,000
✅ NDA
✅ Partnership Agreement
✅ Employment Agreement

Everything you need to launch your business on solid legal ground.
Reviewed by Advocate High Court.

DM or link in bio 👆
#StartupPakistan #DASTAWAIZ

---

13.
IT Business Pack — PKR 22,000
✅ NDA
✅ Software Development Agreement
✅ Service Agreement
✅ Employment Agreement
✅ Privacy Policy

5 documents. One package. Complete protection for your IT company.

DM or link in bio 👆
#SoftwareHousePakistan #DASTAWAIZ

---

--- AUTHORITY ---

14.
At DASTAWAIZ, every document is reviewed by:

Ahsan Awan
⚖️ Advocate High Court
🏢 Corporate Attorney
⚖️ Litigator
📍 Lahore, Pakistan

Not a template generator. Not an algorithm. A real lawyer who reviews every document before it reaches you.

#DASTAWAIZ #AdvocatePakistan #LegalPakistan

---

15.
The difference between DASTAWAIZ and a free template:

Free template:
❌ Generic. Not your situation.
❌ May not apply under Pakistani law
❌ No IP review
❌ No human review
❌ No recourse if it fails

DASTAWAIZ:
✅ Drafted for your exact situation
✅ Pakistani law applied correctly
✅ Reviewed by Advocate High Court
✅ One revision included
✅ Confidential. Professional. Delivered digitally.

Link in bio 👆
#DASTAWAIZ #Pakistan

---

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CONTENT CALENDAR — WEEK 1 (LAUNCH WEEK)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Day 1 (Monday): Brand launch post — "DASTAWAIZ is here. Legal documents made simple." + Ahsan's credentials
Day 2 (Tuesday): Education — Freelancer agreement 7 essentials
Day 3 (Wednesday): Service spotlight — NDA with pricing
Day 4 (Thursday): Red flags post — 7 contract red flags
Day 5 (Friday): Roman Urdu post for wider reach
Day 6 (Saturday): Client protection — "Before you sign..."
Day 7 (Sunday): Rest or repost best-performing post

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HASHTAG SETS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CORE (use always):
#DASTAWAIZ #LegalDocumentsPakistan #ContractPakistan #AdvocatePakistan #LegalPakistan

FREELANCER POSTS:
#FreelancerPakistan #UpworkPakistan #FiverrPakistan #RemoteWorkPakistan #ITFreelancerPakistan

BUSINESS POSTS:
#BusinessPakistan #SMEPakistan #StartupPakistan #EntrepreneurPakistan

IT/TECH POSTS:
#SoftwareHousePakistan #ITExportPakistan #TechPakistan #PSEBPakistan

LAHORE LOCAL:
#LahoreBusiness #LahoreLegal #LahoreStartup

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LINKTREE / LINK-IN-BIO PAGE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Create free account at linktr.ee/dastawaiz

Add these links:
1. 📄 Create My Contract → [Form 1 link]
2. 🔍 Review My Agreement → [Form 2 link]
3. 💬 Ask a Legal Question → [Form 3 link]
4. 💰 Pricing → [Form 1 link with note]
5. 📱 WhatsApp Us → https://wa.me/923459477707

Set this link as bio link on ALL social platforms until website is live.

-e 


# ═══════ 08_future_app_blueprint.md ═══════
# DASTAWAIZ — Future App & Website Blueprint
# Built-in from Day 1 so nothing needs rebuilding later

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PHASE ROADMAP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PHASE 1 — NOW (Zero cost, zero tech)
Google Forms + Sheets + Drive + Gmail + WhatsApp
Takes clients this week.

PHASE 2 — WEBSITE (1–2 months)
WordPress site. Forms embedded. Blog live.
Same workflow, better presence.

PHASE 3 — WEB APP (3–6 months)
Client portal. Document upload. Status tracking.
Voice dictation. Image + PDF upload.
No account needed to submit — just submit and track via email.

PHASE 4 — MOBILE APP (6–12 months)
iOS + Android. Voice-first.
Camera upload — point at a contract, it reads it.
Push notifications for matter status.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VOICE DICTATION — HOW IT WILL WORK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Instead of typing requirements, client speaks them.

Web version (Phase 3):
→ Browser microphone API (already built into Chrome/Safari)
→ Web Speech API converts voice to text in real time
→ Client speaks: "I need a freelancer agreement for a 3-month project with a UK client, payment is $2,000 in two milestones..."
→ Text appears in the form field instantly
→ Client reviews, edits if needed, submits

Mobile app version (Phase 4):
→ Tap microphone icon anywhere in the app
→ Speak naturally
→ AI structures their spoken description into form fields automatically

THIS IS ALREADY TECHNICALLY POSSIBLE AT NEAR-ZERO COST:
→ Web Speech API — free, built into browsers
→ Whisper API (OpenAI) — very cheap for transcription ($0.006/minute)
→ No special infrastructure needed

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IMAGE + PDF UPLOAD — COMPLETE FEATURE PLAN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PHASE 1 (NOW — Google Forms):
✅ PDF upload — already supported in Google Forms (up to 10MB)
✅ Image upload — also supported (JPG, PNG)
Use case: Client uploads scanned contract image → we receive it → review it

PHASE 3 (Web App):
Features to build:
→ Drag and drop upload area
→ Multi-file upload (up to 5 files)
→ File types: PDF, DOC, DOCX, JPG, PNG (scanned contracts)
→ Auto-detect if image needs OCR (convert image text to readable text)
→ Progress bar during upload
→ File preview before submission
→ Secure upload to Google Drive (via API) OR AWS S3 (free tier)

PHASE 4 (Mobile App):
→ Camera button — take photo of contract on the spot
→ Auto-crop and enhance document image
→ OCR reads the text automatically
→ Text sent for review alongside original image
→ Gallery upload for existing photos

TECH STACK FOR THIS (future, all cheap/free):
→ React Native (one codebase → iOS + Android)
→ React (web version)
→ Firebase Storage (free tier: 5GB) for document storage
→ Google Cloud Vision API or Tesseract.js for OCR (reading images)
→ Web Speech API / Whisper for voice

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
COMPLETE FUTURE FEATURE LIST
(Build when revenue justifies it — not before)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INTAKE & SUBMISSION:
✅ Voice dictation (speak your requirements)
✅ PDF upload
✅ Image upload (camera or gallery)
✅ Multi-file upload
✅ Drag-and-drop
✅ Auto-OCR for scanned documents
✅ Auto-fill from uploaded document
✅ Progress bar
✅ Save draft and return later

CLIENT PORTAL:
→ Email-only login (no password — magic link)
→ Matter status tracker ("Your document is in review")
→ Message thread with Ahsan
→ Document download (final versions)
→ Revision request button
→ Invoice and payment history
→ Re-order previous document type

DOCUMENT DELIVERY:
→ Secure time-limited download link
→ In-app document viewer (no download needed)
→ E-signature integration (DocuSign or free alternative)
→ Version history (v1, v2 after revision)
→ Watermarked preview before payment

PAYMENTS:
→ Stripe / Payfast / Easypaisa API integration
→ Pay-now button in email
→ Auto invoice generation
→ Payment receipt
→ Installment option for large packages

NOTIFICATIONS:
→ WhatsApp Business API (automated status updates)
→ Push notifications (app)
→ Email notifications with tracking links
→ SMS fallback

AI FEATURES (Progressive enhancement):
→ Instant AI contract summary when uploaded
→ Risk score (Low / Medium / High) before human review
→ Missing clause detector shown to client
→ Plain English explanation of each clause
→ Urdu translation option
→ "Ask Ahsan AI" — pre-screening chatbot before human response

ADMIN PANEL (Ahsan's side):
→ Web dashboard (not just Google Sheets)
→ One-click Matter ID generation
→ Client folder auto-creation
→ AI draft button (sends to Claude, returns draft)
→ QC checklist built in
→ Email/WhatsApp client directly from dashboard
→ Revenue analytics
→ Lead source tracking chart
→ BTaxFiler/Mr.Laws referral button

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW GOOGLE FORMS FUTURE-PROOFS TO APP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Everything built now maps directly to the future app.

FORM FIELD → APP FIELD:
"Full Name" → name input field
"Document Type" → dropdown selector
"Voice description" → voice input field (add this in Phase 3)
"File Upload" → upload component
"Urgency" → toggle button
"Lead Source" → hidden analytics field

Google Sheets CRM → Database (same columns, same logic)
Google Drive → Cloud storage (same folder structure)
Gmail notifications → Push + WhatsApp notifications
Manual matter ID → Auto-generated in app
Manual QC checklist → Built-in checklist in admin panel

NOTHING GETS THROWN AWAY.
The data model is set up correctly now.
The app is just a better interface on top of the same system.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RECOMMENDED APP DEVELOPMENT PATH
(When ready — not now)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Option A — No-code (cheapest, fastest):
→ Glide Apps (glideapps.com) — builds mobile app from Google Sheets
→ Free tier available
→ Can add voice notes, image upload, status tracking
→ Ready in days, not months
→ Perfect bridge between Phase 1 and Phase 4

Option B — Low-code:
→ Bubble.io — full web app, no coding
→ More power than Glide, more complex
→ Has voice input plugins
→ $29/mo when ready

Option C — Custom (when revenue justifies):
→ React Native developer
→ Builds iOS + Android from one codebase
→ Integrates all features above
→ Hire on Upwork Pakistan (~$15–25/hr)

RECOMMENDATION: Start with Glide Apps in Phase 3.
It reads your Google Sheet directly.
Your data is already there. Zero migration needed.

-e 


# ═══════ 09_7day_action_plan.md ═══════
# DASTAWAIZ — 7-Day Launch Action Plan
# Ahsan Awan, Advocate High Court
# Admin: dastawaizpk@gmail.com | WA: +92 345 9477707

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAY 1 — FOUNDATION (2 hours)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MORNING (1 hour):
□ Sign into dastawaizpk@gmail.com
□ Go to sheets.google.com → create DASTAWAIZ CRM
□ Follow 02_crm_sheet_setup.md exactly
□ Create 5 tabs: LEADS, MATTER ID TRACKER, EMAIL TEMPLATES, PRICING, REFERENCE
□ Add all column headers to LEADS tab
□ Add pricing table to PRICING tab
□ Add Matter ID tracker to MATTER ID TRACKER tab

AFTERNOON (1 hour):
□ Go to drive.google.com
□ Create folder: DASTAWAIZ
□ Inside: DASTAWAIZ Clients → 2026
□ Inside: DASTAWAIZ Internal → Templates, Checklists, Email Templates, Claude Prompts
□ Inside: DASTAWAIZ Website → Images, Logo Files, Blog Drafts
□ Copy all email templates from 02_crm_sheet_setup.md into a Google Doc
□ Save in: DASTAWAIZ Internal → Email Templates

✅ END OF DAY 1: CRM and Drive ready.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAY 2 — GOOGLE FORMS (2.5 hours)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

□ Go to forms.google.com
□ Build Form 1: Create My Contract (follow 03_google_forms.md exactly)
□ Build Form 2: Review My Contract (with file upload)
□ Build Form 3: Ask a Legal Question
□ Link all 3 forms to DASTAWAIZ CRM sheet
□ Test each form: submit a test entry, check if row appears in sheet

INSTALL APPS SCRIPT:
□ Open DASTAWAIZ CRM → Extensions → Apps Script
□ Delete existing code
□ Paste entire 01_apps_script.js
□ Replace YOUR_GMAIL with dastawaizpk@gmail.com (already set)
□ Save → Run → onOpen → Authorize
□ Set trigger: onFormSubmit → On form submit
□ Test: submit a form → check if email arrives at dastawaizpk@gmail.com

SAVE YOUR 3 FORM LINKS:
Form 1 (Create): ___________________________
Form 2 (Review): ___________________________
Form 3 (Question): _________________________

✅ END OF DAY 2: Forms live, automation working, emails sending.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAY 3 — WHATSAPP + GOOGLE BUSINESS (1.5 hours)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

WHATSAPP BUSINESS (45 min):
□ Install WhatsApp Business on phone (separate from personal WA)
□ Set up with 0345-9477707
□ Business name: DASTAWAIZ
□ Category: Professional Services
□ Description: Professional legal document service by Ahsan Awan, Advocate High Court. NDA, contracts, agreements. Pakistan.
□ Set Away Message (copy from page_content)
□ Add Quick Replies:
  /ack — acknowledgment message
  /quote — quotation intro
  /pay — payment instructions
  /done — document ready message

GOOGLE BUSINESS PROFILE (45 min):
□ Go to business.google.com
□ Create profile: DASTAWAIZ
□ Category: Legal Document Preparation Service
□ Phone: +92 345 9477707
□ Email: dastawaizpk@gmail.com
□ Description: copy from 04_page_content.md → Google Business Profile section
□ Start verification process

✅ END OF DAY 3: WhatsApp Business ready. Google Business submitted.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAY 4 — SOCIAL MEDIA + BRANDING (2 hours)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SOCIAL ACCOUNTS (1 hour):
□ Instagram: create @dastawaiz (or @dastawaizpk if taken)
  → Switch to Professional → Business
  → Bio: copy from 04_page_content.md
□ LinkedIn Company Page: DASTAWAIZ
  → Industry: Legal Services
  → Description: copy from 04_page_content.md
□ Facebook Page: DASTAWAIZ
□ Register @dastawaiz on TikTok and YouTube (even if not using yet)

LINKTREE (15 min):
□ Go to linktr.ee → Create free account
□ Username: dastawaiz
□ Add 5 links (Create / Review / Ask / Pricing / WhatsApp)
□ Set this as bio link on all social accounts

CANVA BRANDING (45 min):
□ Go to canva.com → free account
□ Search: "Law firm logo"
□ Colors to use: Deep navy #1B2A4A + Gold #C9A84C + White
□ Font: Playfair Display for DASTAWAIZ, Lato for tagline
□ Create: Logo (square) + Logo (horizontal) + Profile picture
□ Download all as PNG
□ Upload profile picture to all social accounts

✅ END OF DAY 4: Brand live on all platforms.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAY 5 — CONTENT CREATION (2 hours)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

□ Open 06_blog_posts.md
□ Copy Blog Post 1 (Freelancer Agreement) into a Google Doc
□ Save in: DASTAWAIZ Website → Blog Drafts
□ Repeat for all 5 blog posts

□ Open 07_social_media.md
□ Copy first 7 social media captions into a Google Doc
□ Schedule/plan: which post goes on which day

□ Create first 3 social media graphics in Canva:
  → Post 1: Launch announcement
  → Post 2: "7 things your freelancer contract needs"
  → Post 3: NDA spotlight with price

□ Save Claude prompts (05_claude_prompts.md) in Drive → Claude Prompts folder

✅ END OF DAY 5: One week of content ready.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAY 6 — TESTING + SOFT LAUNCH (1 hour)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FINAL CHECKS:
□ Submit test entry on all 3 forms → confirm email arrives
□ Confirm row appears in LEADS sheet
□ Check client acknowledgment email arrives (check spam too)
□ Test "Create Client Folder" button in DASTAWAIZ menu
□ WhatsApp Business receiving messages correctly
□ All social bios have correct link

SOFT LAUNCH:
□ Message 5–10 BTaxFiler contacts: "Launched DASTAWAIZ for legal documents — pass it on"
□ Message 5–10 Mr. Laws contacts
□ Post launch announcement on your personal LinkedIn
□ Post on DASTAWAIZ Instagram and LinkedIn pages

✅ END OF DAY 6: Soft launch complete. First potential leads incoming.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAY 7 — PUBLIC LAUNCH (30 min)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

□ Post launch content on all platforms
□ Share form links in relevant WhatsApp groups (lawyers, IT, startups, freelancers)
□ Post in LinkedIn groups: Pakistani Startups, IT Pakistan, Freelancers Pakistan
□ Reply to all comments and DMs within 2 hours

✅ DASTAWAIZ IS LIVE.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAILY ROUTINE AFTER LAUNCH (30 min/day)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MORNING (10 min):
→ Check dastawaizpk@gmail.com for new lead notifications
→ Open DASTAWAIZ CRM → update any statuses
→ Reply to WhatsApp messages

MIDDAY (10 min):
→ Post one social media piece (caption + graphic from your bank)
→ Respond to comments/DMs

EVENING (10 min):
→ Final email/WA check
→ Any active matters: update status, send any pending responses

That's it. 30 minutes a day runs the entire operation.

